<CharacterDefinition CryXmlVersion="2">
 <Model File="Objects/Characters/hazmat/hamza_final.chr"/>
 <AttachmentList>
  <Attachment Type="CA_SKIN" AName="the_skin" Binding="Objects/Characters/hazmat/hamza_final.skin" Material="Objects/Characters/hazmat/hamza_final.mtl" Flags="0"/>
 </AttachmentList>
</CharacterDefinition>
