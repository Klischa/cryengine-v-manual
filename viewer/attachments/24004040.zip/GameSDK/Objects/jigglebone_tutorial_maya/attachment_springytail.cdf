<CharacterDefinition>
 <Model File="objects/jigglebone_tutorial_maya/ponytail_skel.chr"/>
 <AttachmentList>
  <Attachment Type="CA_SKIN" AName="ponytail_msh" Binding="objects/jigglebone_tutorial_maya/ponytail_msh.skin" Flags="0"/>
  <Attachment Type="CA_BONE" AName="offset rotation" RelRotation="-0.17364818,-5.0637716e-008,0.98480773,-5.0637716e-008" RelPosition="0,0,0" BoneName="sim_ponytail01_JNT" PA_PendulumType="1" PA_MaxAngle="0" PA_Mass="9.9999997e-005" PA_Gravity="0" PA_Damping="0" PA_SimulationAxis="1,0,0" Flags="0"/>
  <Attachment Type="CA_BONE" AName="antenna01" RelRotation="0.70722884,0,-0.70698458,0" RelPosition="0,0,0" BoneName="sim_ponytail01_JNT" SA_SpringType="4" SA_Radius="0" SA_ScaleZP="0" SA_ScaleZN="0" SA_Redirect="1" SA_Mass="0.5" SA_Gravity="0.40000001" SA_Stiffness="150" Flags="0"/>
  <Attachment Type="CA_BONE" AName="antenna02" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail02_JNT" SA_SpringType="4" SA_FPS="60" SA_Radius="0.60000002" SA_Redirect="1" SA_Mass="0.5" SA_Gravity="0.2" SA_Damping="5" SA_Stiffness="10" Flags="0"/>
  <Attachment Type="CA_BONE" AName="antenna03" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail03_JNT" SA_SpringType="4" SA_FPS="60" SA_Radius="0.60000002" SA_Redirect="1" SA_Mass="0.25" SA_Gravity="0.2" SA_Damping="5" SA_Stiffness="10" Flags="0"/>
  <Attachment Type="CA_BONE" AName="antenna04" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail04_JNT" SA_SpringType="4" SA_FPS="60" SA_Radius="0.60000002" SA_Redirect="1" SA_Mass="0.25" SA_Gravity="0.2" SA_Damping="5" SA_Stiffness="10" Flags="0"/>
  <Attachment Type="CA_BONE" AName="antenna05" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail05_JNT" SA_SpringType="4" SA_FPS="60" SA_Radius="0.60000002" SA_Redirect="1" SA_Mass="0.15000001" SA_Gravity="0.2" SA_Damping="5" SA_Stiffness="10" Flags="0"/>
  <Attachment Type="CA_BONE" AName="antenna06" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail06_JNT" SA_SpringType="4" SA_FPS="60" SA_Radius="0.60000002" SA_Redirect="1" SA_Mass="0.15000001" SA_Gravity="0.2" SA_Damping="5" SA_Stiffness="10" Flags="0"/>
  <Attachment Type="CA_BONE" AName="antenna07" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail07_JNT" SA_SpringType="4" SA_FPS="60" SA_Radius="0.60000002" SA_Redirect="1" SA_Mass="0.1" SA_Gravity="0.2" SA_Damping="5" SA_Stiffness="10" Flags="0"/>
 </AttachmentList>
</CharacterDefinition>
