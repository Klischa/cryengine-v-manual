//Maya ASCII 2016ff07 scene
//Name: ponytail_skeleton_step04.ma
//Last modified: Mon, Feb 15, 2016 01:20:52 PM
//Codeset: 1252
requires maya "2016ff07";
requires "stereoCamera" "10.0";
currentUnit -l centimeter -a degree -t ntsc;
fileInfo "application" "maya";
fileInfo "product" "Maya 2016";
fileInfo "version" "2016";
fileInfo "cutIdentifier" "201510022200-973226-1";
fileInfo "osv" "Microsoft Windows 7 Ultimate Edition, 64-bit Windows 7 Service Pack 1 (Build 7601)\n";
createNode transform -s -n "persp";
	rename -uid "5535164F-4441-27B2-7928-2A85F8382E81";
	setAttr ".v" no;
	setAttr ".t" -type "double3" -416.46998782092356 600.51899680737699 368.56707351008811 ;
	setAttr ".r" -type "double3" -24.938352729707116 293.79999999993697 -3.9407653988538573e-015 ;
	setAttr ".rp" -type "double3" 0 -2.1316282072803006e-013 0 ;
	setAttr ".rpt" -type "double3" 1.6138758461006518e-012 6.3972751442396073e-013 -1.4134592259561445e-012 ;
createNode camera -s -n "perspShape" -p "persp";
	rename -uid "22EDC696-4CF4-0ED6-ACD5-6A8838CD6D5B";
	setAttr -k off ".v" no;
	setAttr ".fl" 34.999999999999979;
	setAttr ".coi" 434.87599564661912;
	setAttr ".imn" -type "string" "persp";
	setAttr ".den" -type "string" "persp_depth";
	setAttr ".man" -type "string" "persp_mask";
	setAttr ".tp" -type "double3" 358.92264801377752 -1.2309546910499093e-013 -554.37270879223365 ;
	setAttr ".hc" -type "string" "viewSet -p %camera";
createNode transform -s -n "top";
	rename -uid "E8E2EE9F-44E2-5EA4-137B-65BFD2CA2707";
	setAttr ".v" no;
	setAttr ".t" -type "double3" 0 500.1 0 ;
	setAttr ".r" -type "double3" -89.999999999999986 0 0 ;
createNode camera -s -n "topShape" -p "top";
	rename -uid "F76F6FD0-44D4-9A22-87C3-3D9949F70FC3";
	setAttr -k off ".v" no;
	setAttr ".rnd" no;
	setAttr ".coi" 500.1;
	setAttr ".ow" 30;
	setAttr ".imn" -type "string" "top";
	setAttr ".den" -type "string" "top_depth";
	setAttr ".man" -type "string" "top_mask";
	setAttr ".hc" -type "string" "viewSet -t %camera";
	setAttr ".o" yes;
createNode transform -s -n "front";
	rename -uid "AD330D3D-43AF-E606-3689-8498CD3DB5EA";
	setAttr ".v" no;
	setAttr ".t" -type "double3" 0 0 500.1 ;
createNode camera -s -n "frontShape" -p "front";
	rename -uid "C9F752A2-454C-47F2-8D7E-8CAB312477A2";
	setAttr -k off ".v" no;
	setAttr ".rnd" no;
	setAttr ".coi" 500.1;
	setAttr ".ow" 30;
	setAttr ".imn" -type "string" "front";
	setAttr ".den" -type "string" "front_depth";
	setAttr ".man" -type "string" "front_mask";
	setAttr ".hc" -type "string" "viewSet -f %camera";
	setAttr ".o" yes;
createNode transform -s -n "side";
	rename -uid "4CC18108-4D17-3B2B-59C0-0991F7FFE8D9";
	setAttr ".v" no;
	setAttr ".t" -type "double3" 500.10000000000014 174.24317372378312 -11.377127028096488 ;
	setAttr ".r" -type "double3" 0 89.999999999999986 0 ;
	setAttr ".rp" -type "double3" 1.7763568394002505e-015 2.8421709430404007e-014 0 ;
	setAttr ".rpt" -type "double3" -1.7763568394002509e-015 0 -1.7763568394002509e-015 ;
createNode camera -s -n "sideShape" -p "side";
	rename -uid "EEA01110-4D4D-3AA0-B7DA-218A0815DA79";
	setAttr -k off ".v" no;
	setAttr ".rnd" no;
	setAttr ".coi" 500.10000000000014;
	setAttr ".ow" 13383.458646616513;
	setAttr ".imn" -type "string" "side";
	setAttr ".den" -type "string" "side_depth";
	setAttr ".man" -type "string" "side_mask";
	setAttr ".tp" -type "double3" 0 174.24317372378312 -11.377127028096606 ;
	setAttr ".hc" -type "string" "viewSet -s %camera";
	setAttr ".o" yes;
createNode transform -n "ponytail_SKEL";
	rename -uid "032B9A24-4E71-FE6E-2CEF-D8BD8730A059";
createNode mesh -n "ponytail_SKELShape" -p "ponytail_SKEL";
	rename -uid "D5DB83F5-4E74-50FA-9AAE-A9AB40198734";
	setAttr -k off ".v";
	setAttr -s 2 ".iog[0].og";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".pv" -type "double2" 0.5 0.5 ;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode mesh -n "ponytail_SKELShapeOrig" -p "ponytail_SKEL";
	rename -uid "1692E025-43E7-EB39-0916-54A7A5002757";
	setAttr -k off ".v";
	setAttr ".io" yes;
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode joint -n "targetSkeletonRoot_JNT";
	rename -uid "369A6C60-46EC-BF25-6ABC-0F98F581192F";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".r" -type "double3" -90 0 0 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".bps" -type "matrix" 1 0 0 0 0 2.2204460492503131e-016 -1 0 0 1 2.2204460492503131e-016 0
		 0 0 0 1;
	setAttr ".dl" yes;
	setAttr ".typ" 1;
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode joint -n "targetSkeletonPelvis_JNT" -p "targetSkeletonRoot_JNT";
	rename -uid "06494C90-4DBD-D32B-73F0-498D230E3623";
	addAttr -ci true -sn "liw" -ln "lockInfluenceWeights" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".t" -type "double3" -1.1277741949550301e-013 35 200 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jo" -type "double3" 0 -90 0 ;
	setAttr ".bps" -type "matrix" 2.2204460492503131e-016 1 2.2204460492503131e-016 0
		 0 2.2204460492503131e-016 -1 0 -1 2.2204460492503131e-016 4.9303806576313238e-032 0
		 -1.1277741949550301e-013 200 -34.999999999999957 1;
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "targetSkeleton ( Pelvis )";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode joint -n "targetSkeletonAttachTo_JNT" -p "targetSkeletonPelvis_JNT";
	rename -uid "ADBE9CA2-4610-EE70-C022-B096689E1156";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".oc" 1;
	setAttr ".t" -type "double3" 320 -2.0327728916612404 0 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jo" -type "double3" 0 1.9083328088781097e-014 0 ;
	setAttr ".bps" -type "matrix" 3.3306690738754696e-016 1 1.1102230246251565e-016 0
		 1 -4.9960036108132044e-016 2.2204460492503121e-016 0 1.1102230246251565e-016 -2.2204460492503126e-016 -1.0000000000000002 0
		 0 550 -50 1;
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "targetSkeleton attachment joint ( Head )";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode joint -n "sim_ponytail01_Zero_JNT" -p "targetSkeletonAttachTo_JNT";
	rename -uid "CA642F49-447F-FA4A-6008-93B60B3F502D";
	addAttr -ci true -sn "liw" -ln "lockInfluenceWeights" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".t" -type "double3" -20 -34.999999999999872 0 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jot" -type "string" "xzy";
	setAttr ".jo" -type "double3" -90 0 180 ;
	setAttr ".bps" -type "matrix" -2.2204460492503131e-016 -1.0000000000000002 -3.4450928483976665e-016 0
		 1.0000000000000002 -2.2204460492503146e-016 4.4408920985006257e-016 0 -4.4408920985006271e-016 -3.4450928483976655e-016 1 0
		 -6.4066101166692052e-014 500 -1.4210854715202004e-014 1;
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "ponytail";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode transform -n "ponytail_MSH";
	rename -uid "B0F0C805-4340-8B70-B3C0-29900EC1F154";
	setAttr ".t" -type "double3" 0 325 0 ;
	setAttr -l on ".tx";
	setAttr -l on ".ty";
	setAttr -l on ".tz";
	setAttr -l on ".rx";
	setAttr -l on ".ry";
	setAttr -l on ".rz";
	setAttr -l on ".sx";
	setAttr -l on ".sy";
	setAttr -l on ".sz";
createNode mesh -n "ponytail_MSHShape" -p "ponytail_MSH";
	rename -uid "BB27EDE9-49C5-1546-E965-46A78E884BDF";
	setAttr -k off ".v";
	setAttr -s 4 ".iog[0].og";
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
	setAttr ".vcs" 2;
createNode mesh -n "ponytail_MSHShapeOrig" -p "ponytail_MSH";
	rename -uid "DDEAC344-45BE-A0CF-6656-118D2C29B1A4";
	setAttr -k off ".v";
	setAttr ".io" yes;
	setAttr ".vir" yes;
	setAttr ".vif" yes;
	setAttr ".uvst[0].uvsn" -type "string" "map1";
	setAttr ".cuvs" -type "string" "map1";
	setAttr ".dcc" -type "string" "Ambient+Diffuse";
	setAttr ".covm[0]"  0 1 1;
	setAttr ".cdvm[0]"  0 1 1;
createNode joint -n "sim_ponytail01_JNT";
	rename -uid "90E10717-4950-FD9A-98D5-838035A59BD8";
	addAttr -ci true -sn "liw" -ln "lockInfluenceWeights" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".uoc" 1;
	setAttr ".t" -type "double3" -6.4066101166692052e-014 500 -1.4210854715202029e-014 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jot" -type "string" "xzy";
	setAttr ".jo" -type "double3" 0 0 -90.000000000000014 ;
	setAttr ".bps" -type "matrix" -2.2204460492503131e-016 -1 -0 0 1 -2.2204460492503131e-016 0 0
		 0 -0 1 0 -6.4066101166692052e-014 500 -1.4210854715202029e-014 1;
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "ponytail";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode joint -n "sim_ponytail02_JNT" -p "sim_ponytail01_JNT";
	rename -uid "8DC46999-4804-B06A-E0E9-F5996619A654";
	addAttr -ci true -sn "liw" -ln "lockInfluenceWeights" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".uoc" 1;
	setAttr ".oc" 1;
	setAttr ".t" -type "double3" 50 -9.6655744130405348e-015 0 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jot" -type "string" "xzy";
	setAttr ".bps" -type "matrix" -2.2204460492503131e-016 -1 0 0 1 -2.2204460492503131e-016 0 0
		 0 -0 1 0 -8.4833905825984145e-014 450 -1.4210854715202029e-014 1;
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "ponytail";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode joint -n "sim_ponytail03_JNT" -p "sim_ponytail02_JNT";
	rename -uid "C67219FA-4B26-E960-B5C3-6793C0CD091F";
	addAttr -ci true -sn "liw" -ln "lockInfluenceWeights" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".uoc" 1;
	setAttr ".oc" 2;
	setAttr ".t" -type "double3" 50 -1.376612113372438e-014 7.1054273576010019e-015 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jot" -type "string" "xzy";
	setAttr ".bps" -type "matrix" -2.2204460492503131e-016 -1 0 0 1 -2.2204460492503131e-016 0 0
		 0 -0 1 0 -1.0970225720596009e-013 400 -7.1054273576010271e-015 1;
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "ponytail";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode joint -n "sim_ponytail04_JNT" -p "sim_ponytail03_JNT";
	rename -uid "4C0A9F6D-4C29-BA11-245F-4FA28FBF9723";
	addAttr -ci true -sn "liw" -ln "lockInfluenceWeights" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".uoc" 1;
	setAttr ".oc" 3;
	setAttr ".t" -type "double3" 50 -1.0544262996044242e-014 0 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jot" -type "string" "xzy";
	setAttr ".bps" -type "matrix" -2.2204460492503131e-016 -1 0 0 1 -2.2204460492503131e-016 0 0
		 0 -0 1 0 -1.3134875044825588e-013 350 -7.1054273576010271e-015 1;
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "ponytail";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode joint -n "sim_ponytail05_JNT" -p "sim_ponytail04_JNT";
	rename -uid "1C40CC04-4710-B792-2417-B886229C1EA4";
	addAttr -ci true -sn "liw" -ln "lockInfluenceWeights" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".uoc" 1;
	setAttr ".oc" 4;
	setAttr ".t" -type "double3" 49.999999999999993 -1.1422951579047908e-014 -1.3270634591222572e-013 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jot" -type "string" "xzy";
	setAttr ".bps" -type "matrix" -2.2204460492503131e-016 -1 0 0 1 -2.2204460492503131e-016 0 0
		 0 -0 1 0 -1.5387393227355536e-013 300 -1.3981177326982674e-013 1;
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "ponytail";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode joint -n "sim_ponytail06_JNT" -p "sim_ponytail05_JNT";
	rename -uid "493C278C-4C34-870F-11E2-2D94FC4A71CB";
	addAttr -ci true -sn "liw" -ln "lockInfluenceWeights" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".uoc" 1;
	setAttr ".oc" 5;
	setAttr ".t" -type "double3" 49.99999999999995 -9.9735822264573292e-015 1.7784385075714207e-014 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jot" -type "string" "xzy";
	setAttr ".bps" -type "matrix" -2.2204460492503131e-016 -1 0 0 1 -2.2204460492503131e-016 0 0
		 0 -0 1 0 -1.7494974474626423e-013 250.00000000000006 -1.2202738819411254e-013 1;
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "ponytail";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode joint -n "sim_ponytail07_JNT" -p "sim_ponytail06_JNT";
	rename -uid "962B9BBD-453E-ECC1-5A0F-CEB1F8AA0B27";
	addAttr -ci true -sn "liw" -ln "lockInfluenceWeights" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".uoc" 1;
	setAttr ".oc" 6;
	setAttr ".t" -type "double3" 50.000000000000007 -1.1324565556599799e-014 3.2709945863018725e-014 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jot" -type "string" "none";
	setAttr ".bps" -type "matrix" -2.2204460492503131e-016 -1 0 0 1 -2.2204460492503131e-016 0 0
		 0 -0 1 0 -1.9737654054911561e-013 200.00000000000006 -8.9317442331093818e-014 1;
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "ponytail";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode joint -n "sim_ponytail_END_JNT" -p "sim_ponytail07_JNT";
	rename -uid "ABCFE40A-4772-6C2C-FCBE-7799E3D63263";
	addAttr -ci true -sn "rotXLimited" -ln "rotXLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotYLimited" -ln "rotYLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotZLimited" -ln "rotZLimited" -min 0 -max 1 -at "bool";
	addAttr -ci true -sn "rotLimitMin" -ln "rotLimitMin" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMinX" -ln "rotLimitMinX" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinY" -ln "rotLimitMinY" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMinZ" -ln "rotLimitMinZ" -at "float" -p "rotLimitMin";
	addAttr -ci true -sn "rotLimitMax" -ln "rotLimitMax" -at "float3" -nc 3;
	addAttr -ci true -sn "rotLimitMaxX" -ln "rotLimitMaxX" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxY" -ln "rotLimitMaxY" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "rotLimitMaxZ" -ln "rotLimitMaxZ" -at "float" -p "rotLimitMax";
	addAttr -ci true -sn "spring" -ln "spring" -at "float3" -nc 3;
	addAttr -ci true -sn "springX" -ln "springX" -at "float" -p "spring";
	addAttr -ci true -sn "springY" -ln "springY" -at "float" -p "spring";
	addAttr -ci true -sn "springZ" -ln "springZ" -at "float" -p "spring";
	addAttr -ci true -sn "springTension" -ln "springTension" -at "float3" -nc 3;
	addAttr -ci true -sn "springTensionX" -ln "springTensionX" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionY" -ln "springTensionY" -at "float" -p "springTension";
	addAttr -ci true -sn "springTensionZ" -ln "springTensionZ" -at "float" -p "springTension";
	addAttr -ci true -sn "damping" -ln "damping" -at "float3" -nc 3;
	addAttr -ci true -sn "dampingX" -ln "dampingX" -at "float" -p "damping";
	addAttr -ci true -sn "dampingY" -ln "dampingY" -at "float" -p "damping";
	addAttr -ci true -sn "dampingZ" -ln "dampingZ" -at "float" -p "damping";
	setAttr ".uoc" 1;
	setAttr ".oc" 7;
	setAttr ".t" -type "double3" 50 -1.085943300277618e-014 0 ;
	setAttr ".mnrl" -type "double3" -360 -360 -360 ;
	setAttr ".mxrl" -type "double3" 360 360 360 ;
	setAttr ".dla" yes;
	setAttr ".jot" -type "string" "none";
	setAttr ".dl" yes;
	setAttr ".typ" 18;
	setAttr ".otp" -type "string" "ponytail";
	setAttr ".radi" 2;
	setAttr ".springTension" -type "float3" 1 1 1 ;
	setAttr ".damping" -type "float3" 1 1 1 ;
createNode lightLinker -s -n "lightLinker1";
	rename -uid "1E58D7D7-4210-C37E-DBB9-C686D02314FD";
	setAttr -s 3 ".lnk";
	setAttr -s 3 ".slnk";
createNode displayLayerManager -n "layerManager";
	rename -uid "A9731B01-4025-BC16-D297-259D34A92EE3";
createNode displayLayer -n "defaultLayer";
	rename -uid "9287E225-49D6-1F88-4A1D-EDA7AD7F6D24";
createNode renderLayerManager -n "renderLayerManager";
	rename -uid "58CBC4C3-4F14-3C8E-384C-E2A201F7A597";
createNode renderLayer -n "defaultRenderLayer";
	rename -uid "A38621AD-4827-FBA0-95DA-2ABBA0DF6514";
	setAttr ".g" yes;
createNode script -n "uiConfigurationScriptNode";
	rename -uid "B2B87643-4DCD-FB56-7290-0CBAA54FA064";
	setAttr ".b" -type "string" (
		"// Maya Mel UI Configuration File.\n//\n//  This script is machine generated.  Edit at your own risk.\n//\n//\n\nglobal string $gMainPane;\nif (`paneLayout -exists $gMainPane`) {\n\n\tglobal int $gUseScenePanelConfig;\n\tint    $useSceneConfig = $gUseScenePanelConfig;\n\tint    $menusOkayInPanels = `optionVar -q allowMenusInPanels`;\tint    $nVisPanes = `paneLayout -q -nvp $gMainPane`;\n\tint    $nPanes = 0;\n\tstring $editorName;\n\tstring $panelName;\n\tstring $itemFilterName;\n\tstring $panelConfig;\n\n\t//\n\t//  get current state of the UI\n\t//\n\tsceneUIReplacement -update $gMainPane;\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Top View\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `modelPanel -unParent -l (localizedPanelLabel(\"Top View\")) -mbv $menusOkayInPanels `;\n\t\t\t$editorName = $panelName;\n            modelEditor -e \n                -camera \"top\" \n                -useInteractiveMode 0\n                -displayLights \"default\" \n                -displayAppearance \"smoothShaded\" \n"
		+ "                -activeOnly 0\n                -ignorePanZoom 0\n                -wireframeOnShaded 0\n                -headsUpDisplay 1\n                -holdOuts 1\n                -selectionHiliteDisplay 1\n                -useDefaultMaterial 0\n                -bufferMode \"double\" \n                -twoSidedLighting 0\n                -backfaceCulling 0\n                -xray 0\n                -jointXray 1\n                -activeComponentsXray 0\n                -displayTextures 0\n                -smoothWireframe 0\n                -lineWidth 1\n                -textureAnisotropic 0\n                -textureHilight 1\n                -textureSampling 2\n                -textureDisplay \"modulate\" \n                -textureMaxSize 16384\n                -fogging 0\n                -fogSource \"fragment\" \n                -fogMode \"linear\" \n                -fogStart 0\n                -fogEnd 100\n                -fogDensity 0.1\n                -fogColor 0.5 0.5 0.5 1 \n                -depthOfFieldPreview 1\n                -maxConstantTransparency 1\n"
		+ "                -rendererName \"vp2Renderer\" \n                -objectFilterShowInHUD 1\n                -isFiltered 0\n                -colorResolution 256 256 \n                -bumpResolution 512 512 \n                -textureCompression 0\n                -transparencyAlgorithm \"frontAndBackCull\" \n                -transpInShadows 0\n                -cullingOverride \"none\" \n                -lowQualityLighting 0\n                -maximumNumHardwareLights 1\n                -occlusionCulling 0\n                -shadingModel 0\n                -useBaseRenderer 0\n                -useReducedRenderer 0\n                -smallObjectCulling 0\n                -smallObjectThreshold -1 \n                -interactiveDisableShadows 0\n                -interactiveBackFaceCull 0\n                -sortTransparent 1\n                -nurbsCurves 1\n                -nurbsSurfaces 1\n                -polymeshes 1\n                -subdivSurfaces 1\n                -planes 1\n                -lights 1\n                -cameras 1\n                -controlVertices 1\n"
		+ "                -hulls 1\n                -grid 1\n                -imagePlane 1\n                -joints 1\n                -ikHandles 1\n                -deformers 1\n                -dynamics 1\n                -particleInstancers 1\n                -fluids 1\n                -hairSystems 1\n                -follicles 1\n                -nCloths 1\n                -nParticles 1\n                -nRigids 1\n                -dynamicConstraints 1\n                -locators 1\n                -manipulators 1\n                -pluginShapes 1\n                -dimensions 1\n                -handles 1\n                -pivots 1\n                -textures 1\n                -strokes 1\n                -motionTrails 1\n                -clipGhosts 1\n                -greasePencils 1\n                -shadows 0\n                -captureSequenceNumber -1\n                -width 1\n                -height 1\n                -sceneRenderFilter 0\n                $editorName;\n            modelEditor -e -viewSelected 0 $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n"
		+ "\t\tmodelPanel -edit -l (localizedPanelLabel(\"Top View\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"top\" \n            -useInteractiveMode 0\n            -displayLights \"default\" \n            -displayAppearance \"smoothShaded\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 0\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 1\n            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n"
		+ "            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n"
		+ "            -lights 1\n            -cameras 1\n            -controlVertices 1\n            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -greasePencils 1\n            -shadows 0\n            -captureSequenceNumber -1\n            -width 1\n            -height 1\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Side View\")) `;\n"
		+ "\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `modelPanel -unParent -l (localizedPanelLabel(\"Side View\")) -mbv $menusOkayInPanels `;\n\t\t\t$editorName = $panelName;\n            modelEditor -e \n                -camera \"side\" \n                -useInteractiveMode 0\n                -displayLights \"default\" \n                -displayAppearance \"smoothShaded\" \n                -activeOnly 0\n                -ignorePanZoom 0\n                -wireframeOnShaded 0\n                -headsUpDisplay 1\n                -holdOuts 1\n                -selectionHiliteDisplay 1\n                -useDefaultMaterial 0\n                -bufferMode \"double\" \n                -twoSidedLighting 0\n                -backfaceCulling 0\n                -xray 0\n                -jointXray 1\n                -activeComponentsXray 0\n                -displayTextures 0\n                -smoothWireframe 0\n                -lineWidth 1\n                -textureAnisotropic 0\n                -textureHilight 1\n                -textureSampling 2\n                -textureDisplay \"modulate\" \n"
		+ "                -textureMaxSize 16384\n                -fogging 0\n                -fogSource \"fragment\" \n                -fogMode \"linear\" \n                -fogStart 0\n                -fogEnd 100\n                -fogDensity 0.1\n                -fogColor 0.5 0.5 0.5 1 \n                -depthOfFieldPreview 1\n                -maxConstantTransparency 1\n                -rendererName \"vp2Renderer\" \n                -objectFilterShowInHUD 1\n                -isFiltered 0\n                -colorResolution 256 256 \n                -bumpResolution 512 512 \n                -textureCompression 0\n                -transparencyAlgorithm \"frontAndBackCull\" \n                -transpInShadows 0\n                -cullingOverride \"none\" \n                -lowQualityLighting 0\n                -maximumNumHardwareLights 1\n                -occlusionCulling 0\n                -shadingModel 0\n                -useBaseRenderer 0\n                -useReducedRenderer 0\n                -smallObjectCulling 0\n                -smallObjectThreshold -1 \n"
		+ "                -interactiveDisableShadows 0\n                -interactiveBackFaceCull 0\n                -sortTransparent 1\n                -nurbsCurves 1\n                -nurbsSurfaces 1\n                -polymeshes 1\n                -subdivSurfaces 1\n                -planes 1\n                -lights 1\n                -cameras 1\n                -controlVertices 1\n                -hulls 1\n                -grid 1\n                -imagePlane 1\n                -joints 1\n                -ikHandles 1\n                -deformers 1\n                -dynamics 1\n                -particleInstancers 1\n                -fluids 1\n                -hairSystems 1\n                -follicles 1\n                -nCloths 1\n                -nParticles 1\n                -nRigids 1\n                -dynamicConstraints 1\n                -locators 1\n                -manipulators 1\n                -pluginShapes 1\n                -dimensions 1\n                -handles 1\n                -pivots 1\n                -textures 1\n                -strokes 1\n"
		+ "                -motionTrails 1\n                -clipGhosts 1\n                -greasePencils 1\n                -shadows 0\n                -captureSequenceNumber -1\n                -width 1\n                -height 1\n                -sceneRenderFilter 0\n                $editorName;\n            modelEditor -e -viewSelected 0 $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tmodelPanel -edit -l (localizedPanelLabel(\"Side View\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"side\" \n            -useInteractiveMode 0\n            -displayLights \"default\" \n            -displayAppearance \"smoothShaded\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 0\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 1\n"
		+ "            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n"
		+ "            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n"
		+ "            -motionTrails 1\n            -clipGhosts 1\n            -greasePencils 1\n            -shadows 0\n            -captureSequenceNumber -1\n            -width 1\n            -height 1\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Front View\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `modelPanel -unParent -l (localizedPanelLabel(\"Front View\")) -mbv $menusOkayInPanels `;\n\t\t\t$editorName = $panelName;\n            modelEditor -e \n                -camera \"front\" \n                -useInteractiveMode 0\n                -displayLights \"default\" \n                -displayAppearance \"smoothShaded\" \n                -activeOnly 0\n                -ignorePanZoom 0\n                -wireframeOnShaded 0\n                -headsUpDisplay 1\n                -holdOuts 1\n                -selectionHiliteDisplay 1\n"
		+ "                -useDefaultMaterial 0\n                -bufferMode \"double\" \n                -twoSidedLighting 0\n                -backfaceCulling 0\n                -xray 0\n                -jointXray 1\n                -activeComponentsXray 0\n                -displayTextures 0\n                -smoothWireframe 0\n                -lineWidth 1\n                -textureAnisotropic 0\n                -textureHilight 1\n                -textureSampling 2\n                -textureDisplay \"modulate\" \n                -textureMaxSize 16384\n                -fogging 0\n                -fogSource \"fragment\" \n                -fogMode \"linear\" \n                -fogStart 0\n                -fogEnd 100\n                -fogDensity 0.1\n                -fogColor 0.5 0.5 0.5 1 \n                -depthOfFieldPreview 1\n                -maxConstantTransparency 1\n                -rendererName \"vp2Renderer\" \n                -objectFilterShowInHUD 1\n                -isFiltered 0\n                -colorResolution 256 256 \n                -bumpResolution 512 512 \n"
		+ "                -textureCompression 0\n                -transparencyAlgorithm \"frontAndBackCull\" \n                -transpInShadows 0\n                -cullingOverride \"none\" \n                -lowQualityLighting 0\n                -maximumNumHardwareLights 1\n                -occlusionCulling 0\n                -shadingModel 0\n                -useBaseRenderer 0\n                -useReducedRenderer 0\n                -smallObjectCulling 0\n                -smallObjectThreshold -1 \n                -interactiveDisableShadows 0\n                -interactiveBackFaceCull 0\n                -sortTransparent 1\n                -nurbsCurves 1\n                -nurbsSurfaces 1\n                -polymeshes 1\n                -subdivSurfaces 1\n                -planes 1\n                -lights 1\n                -cameras 1\n                -controlVertices 1\n                -hulls 1\n                -grid 1\n                -imagePlane 1\n                -joints 1\n                -ikHandles 1\n                -deformers 1\n                -dynamics 1\n"
		+ "                -particleInstancers 1\n                -fluids 1\n                -hairSystems 1\n                -follicles 1\n                -nCloths 1\n                -nParticles 1\n                -nRigids 1\n                -dynamicConstraints 1\n                -locators 1\n                -manipulators 1\n                -pluginShapes 1\n                -dimensions 1\n                -handles 1\n                -pivots 1\n                -textures 1\n                -strokes 1\n                -motionTrails 1\n                -clipGhosts 1\n                -greasePencils 1\n                -shadows 0\n                -captureSequenceNumber -1\n                -width 1\n                -height 1\n                -sceneRenderFilter 0\n                $editorName;\n            modelEditor -e -viewSelected 0 $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tmodelPanel -edit -l (localizedPanelLabel(\"Front View\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"front\" \n"
		+ "            -useInteractiveMode 0\n            -displayLights \"default\" \n            -displayAppearance \"smoothShaded\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 0\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 1\n            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n"
		+ "            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n"
		+ "            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -greasePencils 1\n            -shadows 0\n            -captureSequenceNumber -1\n            -width 1\n            -height 1\n            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"modelPanel\" (localizedPanelLabel(\"Persp View\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `modelPanel -unParent -l (localizedPanelLabel(\"Persp View\")) -mbv $menusOkayInPanels `;\n"
		+ "\t\t\t$editorName = $panelName;\n            modelEditor -e \n                -camera \"persp\" \n                -useInteractiveMode 0\n                -displayLights \"default\" \n                -displayAppearance \"smoothShaded\" \n                -activeOnly 0\n                -ignorePanZoom 0\n                -wireframeOnShaded 1\n                -headsUpDisplay 1\n                -holdOuts 1\n                -selectionHiliteDisplay 1\n                -useDefaultMaterial 0\n                -bufferMode \"double\" \n                -twoSidedLighting 0\n                -backfaceCulling 0\n                -xray 0\n                -jointXray 1\n                -activeComponentsXray 0\n                -displayTextures 0\n                -smoothWireframe 0\n                -lineWidth 1\n                -textureAnisotropic 0\n                -textureHilight 1\n                -textureSampling 2\n                -textureDisplay \"modulate\" \n                -textureMaxSize 16384\n                -fogging 0\n                -fogSource \"fragment\" \n                -fogMode \"linear\" \n"
		+ "                -fogStart 0\n                -fogEnd 100\n                -fogDensity 0.1\n                -fogColor 0.5 0.5 0.5 1 \n                -depthOfFieldPreview 1\n                -maxConstantTransparency 1\n                -rendererName \"vp2Renderer\" \n                -objectFilterShowInHUD 1\n                -isFiltered 0\n                -colorResolution 256 256 \n                -bumpResolution 512 512 \n                -textureCompression 0\n                -transparencyAlgorithm \"frontAndBackCull\" \n                -transpInShadows 0\n                -cullingOverride \"none\" \n                -lowQualityLighting 0\n                -maximumNumHardwareLights 1\n                -occlusionCulling 0\n                -shadingModel 0\n                -useBaseRenderer 0\n                -useReducedRenderer 0\n                -smallObjectCulling 0\n                -smallObjectThreshold -1 \n                -interactiveDisableShadows 0\n                -interactiveBackFaceCull 0\n                -sortTransparent 1\n                -nurbsCurves 1\n"
		+ "                -nurbsSurfaces 1\n                -polymeshes 1\n                -subdivSurfaces 1\n                -planes 1\n                -lights 1\n                -cameras 1\n                -controlVertices 1\n                -hulls 1\n                -grid 1\n                -imagePlane 1\n                -joints 1\n                -ikHandles 1\n                -deformers 1\n                -dynamics 1\n                -particleInstancers 1\n                -fluids 1\n                -hairSystems 1\n                -follicles 1\n                -nCloths 1\n                -nParticles 1\n                -nRigids 1\n                -dynamicConstraints 1\n                -locators 1\n                -manipulators 1\n                -pluginShapes 1\n                -dimensions 1\n                -handles 1\n                -pivots 1\n                -textures 1\n                -strokes 1\n                -motionTrails 1\n                -clipGhosts 1\n                -greasePencils 1\n                -shadows 0\n                -captureSequenceNumber -1\n"
		+ "                -width 1028\n                -height 712\n                -sceneRenderFilter 0\n                $editorName;\n            modelEditor -e -viewSelected 0 $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tmodelPanel -edit -l (localizedPanelLabel(\"Persp View\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        modelEditor -e \n            -camera \"persp\" \n            -useInteractiveMode 0\n            -displayLights \"default\" \n            -displayAppearance \"smoothShaded\" \n            -activeOnly 0\n            -ignorePanZoom 0\n            -wireframeOnShaded 1\n            -headsUpDisplay 1\n            -holdOuts 1\n            -selectionHiliteDisplay 1\n            -useDefaultMaterial 0\n            -bufferMode \"double\" \n            -twoSidedLighting 0\n            -backfaceCulling 0\n            -xray 0\n            -jointXray 1\n            -activeComponentsXray 0\n            -displayTextures 0\n            -smoothWireframe 0\n            -lineWidth 1\n            -textureAnisotropic 0\n"
		+ "            -textureHilight 1\n            -textureSampling 2\n            -textureDisplay \"modulate\" \n            -textureMaxSize 16384\n            -fogging 0\n            -fogSource \"fragment\" \n            -fogMode \"linear\" \n            -fogStart 0\n            -fogEnd 100\n            -fogDensity 0.1\n            -fogColor 0.5 0.5 0.5 1 \n            -depthOfFieldPreview 1\n            -maxConstantTransparency 1\n            -rendererName \"vp2Renderer\" \n            -objectFilterShowInHUD 1\n            -isFiltered 0\n            -colorResolution 256 256 \n            -bumpResolution 512 512 \n            -textureCompression 0\n            -transparencyAlgorithm \"frontAndBackCull\" \n            -transpInShadows 0\n            -cullingOverride \"none\" \n            -lowQualityLighting 0\n            -maximumNumHardwareLights 1\n            -occlusionCulling 0\n            -shadingModel 0\n            -useBaseRenderer 0\n            -useReducedRenderer 0\n            -smallObjectCulling 0\n            -smallObjectThreshold -1 \n            -interactiveDisableShadows 0\n"
		+ "            -interactiveBackFaceCull 0\n            -sortTransparent 1\n            -nurbsCurves 1\n            -nurbsSurfaces 1\n            -polymeshes 1\n            -subdivSurfaces 1\n            -planes 1\n            -lights 1\n            -cameras 1\n            -controlVertices 1\n            -hulls 1\n            -grid 1\n            -imagePlane 1\n            -joints 1\n            -ikHandles 1\n            -deformers 1\n            -dynamics 1\n            -particleInstancers 1\n            -fluids 1\n            -hairSystems 1\n            -follicles 1\n            -nCloths 1\n            -nParticles 1\n            -nRigids 1\n            -dynamicConstraints 1\n            -locators 1\n            -manipulators 1\n            -pluginShapes 1\n            -dimensions 1\n            -handles 1\n            -pivots 1\n            -textures 1\n            -strokes 1\n            -motionTrails 1\n            -clipGhosts 1\n            -greasePencils 1\n            -shadows 0\n            -captureSequenceNumber -1\n            -width 1028\n            -height 712\n"
		+ "            -sceneRenderFilter 0\n            $editorName;\n        modelEditor -e -viewSelected 0 $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"outlinerPanel\" (localizedPanelLabel(\"Outliner\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `outlinerPanel -unParent -l (localizedPanelLabel(\"Outliner\")) -mbv $menusOkayInPanels `;\n\t\t\t$editorName = $panelName;\n            outlinerEditor -e \n                -docTag \"isolOutln_fromSeln\" \n                -showShapes 0\n                -showReferenceNodes 1\n                -showReferenceMembers 1\n                -showAttributes 0\n                -showConnected 0\n                -showAnimCurvesOnly 0\n                -showMuteInfo 0\n                -organizeByLayer 1\n                -showAnimLayerWeight 1\n                -autoExpandLayers 1\n                -autoExpand 0\n                -showDagOnly 1\n                -showAssets 1\n                -showContainedOnly 1\n                -showPublishedAsConnected 0\n"
		+ "                -showContainerContents 1\n                -ignoreDagHierarchy 0\n                -expandConnections 0\n                -showUpstreamCurves 1\n                -showUnitlessCurves 1\n                -showCompounds 1\n                -showLeafs 1\n                -showNumericAttrsOnly 0\n                -highlightActive 1\n                -autoSelectNewObjects 0\n                -doNotSelectNewObjects 0\n                -dropIsParent 1\n                -transmitFilters 0\n                -setFilter \"defaultSetFilter\" \n                -showSetMembers 1\n                -allowMultiSelection 1\n                -alwaysToggleSelect 0\n                -directSelect 0\n                -displayMode \"DAG\" \n                -expandObjects 0\n                -setsIgnoreFilters 1\n                -containersIgnoreFilters 0\n                -editAttrName 0\n                -showAttrValues 0\n                -highlightSecondary 0\n                -showUVAttrsOnly 0\n                -showTextureNodesOnly 0\n                -attrAlphaOrder \"default\" \n"
		+ "                -animLayerFilterOptions \"allAffecting\" \n                -sortOrder \"none\" \n                -longNames 0\n                -niceNames 1\n                -showNamespace 1\n                -showPinIcons 0\n                -mapMotionTrails 0\n                -ignoreHiddenAttribute 0\n                -ignoreOutlinerColor 0\n                $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\toutlinerPanel -edit -l (localizedPanelLabel(\"Outliner\")) -mbv $menusOkayInPanels  $panelName;\n\t\t$editorName = $panelName;\n        outlinerEditor -e \n            -docTag \"isolOutln_fromSeln\" \n            -showShapes 0\n            -showReferenceNodes 1\n            -showReferenceMembers 1\n            -showAttributes 0\n            -showConnected 0\n            -showAnimCurvesOnly 0\n            -showMuteInfo 0\n            -organizeByLayer 1\n            -showAnimLayerWeight 1\n            -autoExpandLayers 1\n            -autoExpand 0\n            -showDagOnly 1\n            -showAssets 1\n            -showContainedOnly 1\n"
		+ "            -showPublishedAsConnected 0\n            -showContainerContents 1\n            -ignoreDagHierarchy 0\n            -expandConnections 0\n            -showUpstreamCurves 1\n            -showUnitlessCurves 1\n            -showCompounds 1\n            -showLeafs 1\n            -showNumericAttrsOnly 0\n            -highlightActive 1\n            -autoSelectNewObjects 0\n            -doNotSelectNewObjects 0\n            -dropIsParent 1\n            -transmitFilters 0\n            -setFilter \"defaultSetFilter\" \n            -showSetMembers 1\n            -allowMultiSelection 1\n            -alwaysToggleSelect 0\n            -directSelect 0\n            -displayMode \"DAG\" \n            -expandObjects 0\n            -setsIgnoreFilters 1\n            -containersIgnoreFilters 0\n            -editAttrName 0\n            -showAttrValues 0\n            -highlightSecondary 0\n            -showUVAttrsOnly 0\n            -showTextureNodesOnly 0\n            -attrAlphaOrder \"default\" \n            -animLayerFilterOptions \"allAffecting\" \n            -sortOrder \"none\" \n"
		+ "            -longNames 0\n            -niceNames 1\n            -showNamespace 1\n            -showPinIcons 0\n            -mapMotionTrails 0\n            -ignoreHiddenAttribute 0\n            -ignoreOutlinerColor 0\n            $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"graphEditor\" (localizedPanelLabel(\"Graph Editor\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"graphEditor\" -l (localizedPanelLabel(\"Graph Editor\")) -mbv $menusOkayInPanels `;\n\n\t\t\t$editorName = ($panelName+\"OutlineEd\");\n            outlinerEditor -e \n                -showShapes 1\n                -showReferenceNodes 0\n                -showReferenceMembers 0\n                -showAttributes 1\n                -showConnected 1\n                -showAnimCurvesOnly 1\n                -showMuteInfo 0\n                -organizeByLayer 1\n                -showAnimLayerWeight 1\n                -autoExpandLayers 1\n"
		+ "                -autoExpand 1\n                -showDagOnly 0\n                -showAssets 1\n                -showContainedOnly 0\n                -showPublishedAsConnected 0\n                -showContainerContents 0\n                -ignoreDagHierarchy 0\n                -expandConnections 1\n                -showUpstreamCurves 1\n                -showUnitlessCurves 1\n                -showCompounds 0\n                -showLeafs 1\n                -showNumericAttrsOnly 1\n                -highlightActive 0\n                -autoSelectNewObjects 1\n                -doNotSelectNewObjects 0\n                -dropIsParent 1\n                -transmitFilters 1\n                -setFilter \"0\" \n                -showSetMembers 0\n                -allowMultiSelection 1\n                -alwaysToggleSelect 0\n                -directSelect 0\n                -displayMode \"DAG\" \n                -expandObjects 0\n                -setsIgnoreFilters 1\n                -containersIgnoreFilters 0\n                -editAttrName 0\n                -showAttrValues 0\n"
		+ "                -highlightSecondary 0\n                -showUVAttrsOnly 0\n                -showTextureNodesOnly 0\n                -attrAlphaOrder \"default\" \n                -animLayerFilterOptions \"allAffecting\" \n                -sortOrder \"none\" \n                -longNames 0\n                -niceNames 1\n                -showNamespace 1\n                -showPinIcons 1\n                -mapMotionTrails 1\n                -ignoreHiddenAttribute 0\n                -ignoreOutlinerColor 0\n                $editorName;\n\n\t\t\t$editorName = ($panelName+\"GraphEd\");\n            animCurveEditor -e \n                -displayKeys 1\n                -displayTangents 0\n                -displayActiveKeys 0\n                -displayActiveKeyTangents 1\n                -displayInfinities 0\n                -autoFit 0\n                -snapTime \"integer\" \n                -snapValue \"none\" \n                -showResults \"off\" \n                -showBufferCurves \"off\" \n                -smoothness \"fine\" \n                -resultSamples 1.25\n                -resultScreenSamples 0\n"
		+ "                -resultUpdate \"delayed\" \n                -showUpstreamCurves 1\n                -stackedCurves 0\n                -stackedCurvesMin -1\n                -stackedCurvesMax 1\n                -stackedCurvesSpace 0.2\n                -displayNormalized 0\n                -preSelectionHighlight 0\n                -constrainDrag 0\n                -classicMode 1\n                $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Graph Editor\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = ($panelName+\"OutlineEd\");\n            outlinerEditor -e \n                -showShapes 1\n                -showReferenceNodes 0\n                -showReferenceMembers 0\n                -showAttributes 1\n                -showConnected 1\n                -showAnimCurvesOnly 1\n                -showMuteInfo 0\n                -organizeByLayer 1\n                -showAnimLayerWeight 1\n                -autoExpandLayers 1\n                -autoExpand 1\n                -showDagOnly 0\n"
		+ "                -showAssets 1\n                -showContainedOnly 0\n                -showPublishedAsConnected 0\n                -showContainerContents 0\n                -ignoreDagHierarchy 0\n                -expandConnections 1\n                -showUpstreamCurves 1\n                -showUnitlessCurves 1\n                -showCompounds 0\n                -showLeafs 1\n                -showNumericAttrsOnly 1\n                -highlightActive 0\n                -autoSelectNewObjects 1\n                -doNotSelectNewObjects 0\n                -dropIsParent 1\n                -transmitFilters 1\n                -setFilter \"0\" \n                -showSetMembers 0\n                -allowMultiSelection 1\n                -alwaysToggleSelect 0\n                -directSelect 0\n                -displayMode \"DAG\" \n                -expandObjects 0\n                -setsIgnoreFilters 1\n                -containersIgnoreFilters 0\n                -editAttrName 0\n                -showAttrValues 0\n                -highlightSecondary 0\n                -showUVAttrsOnly 0\n"
		+ "                -showTextureNodesOnly 0\n                -attrAlphaOrder \"default\" \n                -animLayerFilterOptions \"allAffecting\" \n                -sortOrder \"none\" \n                -longNames 0\n                -niceNames 1\n                -showNamespace 1\n                -showPinIcons 1\n                -mapMotionTrails 1\n                -ignoreHiddenAttribute 0\n                -ignoreOutlinerColor 0\n                $editorName;\n\n\t\t\t$editorName = ($panelName+\"GraphEd\");\n            animCurveEditor -e \n                -displayKeys 1\n                -displayTangents 0\n                -displayActiveKeys 0\n                -displayActiveKeyTangents 1\n                -displayInfinities 0\n                -autoFit 0\n                -snapTime \"integer\" \n                -snapValue \"none\" \n                -showResults \"off\" \n                -showBufferCurves \"off\" \n                -smoothness \"fine\" \n                -resultSamples 1.25\n                -resultScreenSamples 0\n                -resultUpdate \"delayed\" \n"
		+ "                -showUpstreamCurves 1\n                -stackedCurves 0\n                -stackedCurvesMin -1\n                -stackedCurvesMax 1\n                -stackedCurvesSpace 0.2\n                -displayNormalized 0\n                -preSelectionHighlight 0\n                -constrainDrag 0\n                -classicMode 1\n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"dopeSheetPanel\" (localizedPanelLabel(\"Dope Sheet\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"dopeSheetPanel\" -l (localizedPanelLabel(\"Dope Sheet\")) -mbv $menusOkayInPanels `;\n\n\t\t\t$editorName = ($panelName+\"OutlineEd\");\n            outlinerEditor -e \n                -showShapes 1\n                -showReferenceNodes 0\n                -showReferenceMembers 0\n                -showAttributes 1\n                -showConnected 1\n                -showAnimCurvesOnly 1\n                -showMuteInfo 0\n"
		+ "                -organizeByLayer 1\n                -showAnimLayerWeight 1\n                -autoExpandLayers 1\n                -autoExpand 0\n                -showDagOnly 0\n                -showAssets 1\n                -showContainedOnly 0\n                -showPublishedAsConnected 0\n                -showContainerContents 0\n                -ignoreDagHierarchy 0\n                -expandConnections 1\n                -showUpstreamCurves 1\n                -showUnitlessCurves 0\n                -showCompounds 1\n                -showLeafs 1\n                -showNumericAttrsOnly 1\n                -highlightActive 0\n                -autoSelectNewObjects 0\n                -doNotSelectNewObjects 1\n                -dropIsParent 1\n                -transmitFilters 0\n                -setFilter \"0\" \n                -showSetMembers 0\n                -allowMultiSelection 1\n                -alwaysToggleSelect 0\n                -directSelect 0\n                -displayMode \"DAG\" \n                -expandObjects 0\n                -setsIgnoreFilters 1\n"
		+ "                -containersIgnoreFilters 0\n                -editAttrName 0\n                -showAttrValues 0\n                -highlightSecondary 0\n                -showUVAttrsOnly 0\n                -showTextureNodesOnly 0\n                -attrAlphaOrder \"default\" \n                -animLayerFilterOptions \"allAffecting\" \n                -sortOrder \"none\" \n                -longNames 0\n                -niceNames 1\n                -showNamespace 1\n                -showPinIcons 0\n                -mapMotionTrails 1\n                -ignoreHiddenAttribute 0\n                -ignoreOutlinerColor 0\n                $editorName;\n\n\t\t\t$editorName = ($panelName+\"DopeSheetEd\");\n            dopeSheetEditor -e \n                -displayKeys 1\n                -displayTangents 0\n                -displayActiveKeys 0\n                -displayActiveKeyTangents 0\n                -displayInfinities 0\n                -autoFit 0\n                -snapTime \"integer\" \n                -snapValue \"none\" \n                -outliner \"dopeSheetPanel1OutlineEd\" \n"
		+ "                -showSummary 1\n                -showScene 0\n                -hierarchyBelow 0\n                -showTicks 1\n                -selectionWindow 0 0 0 0 \n                $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Dope Sheet\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = ($panelName+\"OutlineEd\");\n            outlinerEditor -e \n                -showShapes 1\n                -showReferenceNodes 0\n                -showReferenceMembers 0\n                -showAttributes 1\n                -showConnected 1\n                -showAnimCurvesOnly 1\n                -showMuteInfo 0\n                -organizeByLayer 1\n                -showAnimLayerWeight 1\n                -autoExpandLayers 1\n                -autoExpand 0\n                -showDagOnly 0\n                -showAssets 1\n                -showContainedOnly 0\n                -showPublishedAsConnected 0\n                -showContainerContents 0\n                -ignoreDagHierarchy 0\n"
		+ "                -expandConnections 1\n                -showUpstreamCurves 1\n                -showUnitlessCurves 0\n                -showCompounds 1\n                -showLeafs 1\n                -showNumericAttrsOnly 1\n                -highlightActive 0\n                -autoSelectNewObjects 0\n                -doNotSelectNewObjects 1\n                -dropIsParent 1\n                -transmitFilters 0\n                -setFilter \"0\" \n                -showSetMembers 0\n                -allowMultiSelection 1\n                -alwaysToggleSelect 0\n                -directSelect 0\n                -displayMode \"DAG\" \n                -expandObjects 0\n                -setsIgnoreFilters 1\n                -containersIgnoreFilters 0\n                -editAttrName 0\n                -showAttrValues 0\n                -highlightSecondary 0\n                -showUVAttrsOnly 0\n                -showTextureNodesOnly 0\n                -attrAlphaOrder \"default\" \n                -animLayerFilterOptions \"allAffecting\" \n                -sortOrder \"none\" \n"
		+ "                -longNames 0\n                -niceNames 1\n                -showNamespace 1\n                -showPinIcons 0\n                -mapMotionTrails 1\n                -ignoreHiddenAttribute 0\n                -ignoreOutlinerColor 0\n                $editorName;\n\n\t\t\t$editorName = ($panelName+\"DopeSheetEd\");\n            dopeSheetEditor -e \n                -displayKeys 1\n                -displayTangents 0\n                -displayActiveKeys 0\n                -displayActiveKeyTangents 0\n                -displayInfinities 0\n                -autoFit 0\n                -snapTime \"integer\" \n                -snapValue \"none\" \n                -outliner \"dopeSheetPanel1OutlineEd\" \n                -showSummary 1\n                -showScene 0\n                -hierarchyBelow 0\n                -showTicks 1\n                -selectionWindow 0 0 0 0 \n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"clipEditorPanel\" (localizedPanelLabel(\"Trax Editor\")) `;\n"
		+ "\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"clipEditorPanel\" -l (localizedPanelLabel(\"Trax Editor\")) -mbv $menusOkayInPanels `;\n\n\t\t\t$editorName = clipEditorNameFromPanel($panelName);\n            clipEditor -e \n                -displayKeys 0\n                -displayTangents 0\n                -displayActiveKeys 0\n                -displayActiveKeyTangents 0\n                -displayInfinities 0\n                -autoFit 0\n                -snapTime \"none\" \n                -snapValue \"none\" \n                -manageSequencer 0 \n                $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Trax Editor\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = clipEditorNameFromPanel($panelName);\n            clipEditor -e \n                -displayKeys 0\n                -displayTangents 0\n                -displayActiveKeys 0\n                -displayActiveKeyTangents 0\n                -displayInfinities 0\n"
		+ "                -autoFit 0\n                -snapTime \"none\" \n                -snapValue \"none\" \n                -manageSequencer 0 \n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"sequenceEditorPanel\" (localizedPanelLabel(\"Camera Sequencer\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"sequenceEditorPanel\" -l (localizedPanelLabel(\"Camera Sequencer\")) -mbv $menusOkayInPanels `;\n\n\t\t\t$editorName = sequenceEditorNameFromPanel($panelName);\n            clipEditor -e \n                -displayKeys 0\n                -displayTangents 0\n                -displayActiveKeys 0\n                -displayActiveKeyTangents 0\n                -displayInfinities 0\n                -autoFit 0\n                -snapTime \"none\" \n                -snapValue \"none\" \n                -manageSequencer 1 \n                $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n"
		+ "\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Camera Sequencer\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = sequenceEditorNameFromPanel($panelName);\n            clipEditor -e \n                -displayKeys 0\n                -displayTangents 0\n                -displayActiveKeys 0\n                -displayActiveKeyTangents 0\n                -displayInfinities 0\n                -autoFit 0\n                -snapTime \"none\" \n                -snapValue \"none\" \n                -manageSequencer 1 \n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"hyperGraphPanel\" (localizedPanelLabel(\"Hypergraph Hierarchy\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"hyperGraphPanel\" -l (localizedPanelLabel(\"Hypergraph Hierarchy\")) -mbv $menusOkayInPanels `;\n\n\t\t\t$editorName = ($panelName+\"HyperGraphEd\");\n            hyperGraph -e \n                -graphLayoutStyle \"hierarchicalLayout\" \n"
		+ "                -orientation \"horiz\" \n                -mergeConnections 0\n                -zoom 1\n                -animateTransition 0\n                -showRelationships 1\n                -showShapes 0\n                -showDeformers 0\n                -showExpressions 0\n                -showConstraints 0\n                -showConnectionFromSelected 0\n                -showConnectionToSelected 0\n                -showConstraintLabels 0\n                -showUnderworld 0\n                -showInvisible 0\n                -transitionFrames 1\n                -opaqueContainers 0\n                -freeform 0\n                -imagePosition 0 0 \n                -imageScale 1\n                -imageEnabled 0\n                -graphType \"DAG\" \n                -heatMapDisplay 0\n                -updateSelection 1\n                -updateNodeAdded 1\n                -useDrawOverrideColor 0\n                -limitGraphTraversal -1\n                -range 0 0 \n                -iconSize \"smallIcons\" \n                -showCachedConnections 0\n"
		+ "                $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Hypergraph Hierarchy\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = ($panelName+\"HyperGraphEd\");\n            hyperGraph -e \n                -graphLayoutStyle \"hierarchicalLayout\" \n                -orientation \"horiz\" \n                -mergeConnections 0\n                -zoom 1\n                -animateTransition 0\n                -showRelationships 1\n                -showShapes 0\n                -showDeformers 0\n                -showExpressions 0\n                -showConstraints 0\n                -showConnectionFromSelected 0\n                -showConnectionToSelected 0\n                -showConstraintLabels 0\n                -showUnderworld 0\n                -showInvisible 0\n                -transitionFrames 1\n                -opaqueContainers 0\n                -freeform 0\n                -imagePosition 0 0 \n                -imageScale 1\n                -imageEnabled 0\n                -graphType \"DAG\" \n"
		+ "                -heatMapDisplay 0\n                -updateSelection 1\n                -updateNodeAdded 1\n                -useDrawOverrideColor 0\n                -limitGraphTraversal -1\n                -range 0 0 \n                -iconSize \"smallIcons\" \n                -showCachedConnections 0\n                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"visorPanel\" (localizedPanelLabel(\"Visor\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"visorPanel\" -l (localizedPanelLabel(\"Visor\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Visor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"createNodePanel\" (localizedPanelLabel(\"Create Node\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n"
		+ "\t\t\t$panelName = `scriptedPanel -unParent  -type \"createNodePanel\" -l (localizedPanelLabel(\"Create Node\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Create Node\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"polyTexturePlacementPanel\" (localizedPanelLabel(\"UV Editor\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"polyTexturePlacementPanel\" -l (localizedPanelLabel(\"UV Editor\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"UV Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"renderWindowPanel\" (localizedPanelLabel(\"Render View\")) `;\n\tif (\"\" == $panelName) {\n"
		+ "\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"renderWindowPanel\" -l (localizedPanelLabel(\"Render View\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Render View\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextPanel \"blendShapePanel\" (localizedPanelLabel(\"Blend Shape\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\tblendShapePanel -unParent -l (localizedPanelLabel(\"Blend Shape\")) -mbv $menusOkayInPanels ;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tblendShapePanel -edit -l (localizedPanelLabel(\"Blend Shape\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"dynRelEdPanel\" (localizedPanelLabel(\"Dynamic Relationships\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n"
		+ "\t\t\t$panelName = `scriptedPanel -unParent  -type \"dynRelEdPanel\" -l (localizedPanelLabel(\"Dynamic Relationships\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Dynamic Relationships\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"relationshipPanel\" (localizedPanelLabel(\"Relationship Editor\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"relationshipPanel\" -l (localizedPanelLabel(\"Relationship Editor\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Relationship Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"referenceEditorPanel\" (localizedPanelLabel(\"Reference Editor\")) `;\n"
		+ "\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"referenceEditorPanel\" -l (localizedPanelLabel(\"Reference Editor\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Reference Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"componentEditorPanel\" (localizedPanelLabel(\"Component Editor\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"componentEditorPanel\" -l (localizedPanelLabel(\"Component Editor\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Component Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"dynPaintScriptedPanelType\" (localizedPanelLabel(\"Paint Effects\")) `;\n"
		+ "\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"dynPaintScriptedPanelType\" -l (localizedPanelLabel(\"Paint Effects\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Paint Effects\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"scriptEditorPanel\" (localizedPanelLabel(\"Script Editor\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"scriptEditorPanel\" -l (localizedPanelLabel(\"Script Editor\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Script Editor\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"profilerPanel\" (localizedPanelLabel(\"Profiler Tool\")) `;\n"
		+ "\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"profilerPanel\" -l (localizedPanelLabel(\"Profiler Tool\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Profiler Tool\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"Stereo\" (localizedPanelLabel(\"Stereo\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"Stereo\" -l (localizedPanelLabel(\"Stereo\")) -mbv $menusOkayInPanels `;\nstring $editorName = ($panelName+\"Editor\");\n            stereoCameraView -e \n                -camera \"persp\" \n                -useInteractiveMode 0\n                -displayLights \"default\" \n                -displayAppearance \"wireframe\" \n                -activeOnly 0\n                -ignorePanZoom 0\n                -wireframeOnShaded 0\n                -headsUpDisplay 1\n"
		+ "                -holdOuts 1\n                -selectionHiliteDisplay 1\n                -useDefaultMaterial 0\n                -bufferMode \"double\" \n                -twoSidedLighting 1\n                -backfaceCulling 0\n                -xray 0\n                -jointXray 0\n                -activeComponentsXray 0\n                -displayTextures 0\n                -smoothWireframe 0\n                -lineWidth 1\n                -textureAnisotropic 0\n                -textureHilight 1\n                -textureSampling 2\n                -textureDisplay \"modulate\" \n                -textureMaxSize 16384\n                -fogging 0\n                -fogSource \"fragment\" \n                -fogMode \"linear\" \n                -fogStart 0\n                -fogEnd 100\n                -fogDensity 0.1\n                -fogColor 0.5 0.5 0.5 1 \n                -depthOfFieldPreview 1\n                -maxConstantTransparency 1\n                -objectFilterShowInHUD 1\n                -isFiltered 0\n                -colorResolution 4 4 \n                -bumpResolution 4 4 \n"
		+ "                -textureCompression 0\n                -transparencyAlgorithm \"frontAndBackCull\" \n                -transpInShadows 0\n                -cullingOverride \"none\" \n                -lowQualityLighting 0\n                -maximumNumHardwareLights 0\n                -occlusionCulling 0\n                -shadingModel 0\n                -useBaseRenderer 0\n                -useReducedRenderer 0\n                -smallObjectCulling 0\n                -smallObjectThreshold -1 \n                -interactiveDisableShadows 0\n                -interactiveBackFaceCull 0\n                -sortTransparent 1\n                -nurbsCurves 1\n                -nurbsSurfaces 1\n                -polymeshes 1\n                -subdivSurfaces 1\n                -planes 1\n                -lights 1\n                -cameras 1\n                -controlVertices 1\n                -hulls 1\n                -grid 1\n                -imagePlane 1\n                -joints 1\n                -ikHandles 1\n                -deformers 1\n                -dynamics 1\n"
		+ "                -particleInstancers 1\n                -fluids 1\n                -hairSystems 1\n                -follicles 1\n                -nCloths 1\n                -nParticles 1\n                -nRigids 1\n                -dynamicConstraints 1\n                -locators 1\n                -manipulators 1\n                -pluginShapes 1\n                -dimensions 1\n                -handles 1\n                -pivots 1\n                -textures 1\n                -strokes 1\n                -motionTrails 1\n                -clipGhosts 1\n                -greasePencils 1\n                -shadows 0\n                -captureSequenceNumber -1\n                -width 0\n                -height 0\n                -sceneRenderFilter 0\n                -displayMode \"centerEye\" \n                -viewColor 0 0 0 1 \n                -useCustomBackground 1\n                $editorName;\n            stereoCameraView -e -viewSelected 0 $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Stereo\")) -mbv $menusOkayInPanels  $panelName;\n"
		+ "string $editorName = ($panelName+\"Editor\");\n            stereoCameraView -e \n                -camera \"persp\" \n                -useInteractiveMode 0\n                -displayLights \"default\" \n                -displayAppearance \"wireframe\" \n                -activeOnly 0\n                -ignorePanZoom 0\n                -wireframeOnShaded 0\n                -headsUpDisplay 1\n                -holdOuts 1\n                -selectionHiliteDisplay 1\n                -useDefaultMaterial 0\n                -bufferMode \"double\" \n                -twoSidedLighting 1\n                -backfaceCulling 0\n                -xray 0\n                -jointXray 0\n                -activeComponentsXray 0\n                -displayTextures 0\n                -smoothWireframe 0\n                -lineWidth 1\n                -textureAnisotropic 0\n                -textureHilight 1\n                -textureSampling 2\n                -textureDisplay \"modulate\" \n                -textureMaxSize 16384\n                -fogging 0\n                -fogSource \"fragment\" \n"
		+ "                -fogMode \"linear\" \n                -fogStart 0\n                -fogEnd 100\n                -fogDensity 0.1\n                -fogColor 0.5 0.5 0.5 1 \n                -depthOfFieldPreview 1\n                -maxConstantTransparency 1\n                -objectFilterShowInHUD 1\n                -isFiltered 0\n                -colorResolution 4 4 \n                -bumpResolution 4 4 \n                -textureCompression 0\n                -transparencyAlgorithm \"frontAndBackCull\" \n                -transpInShadows 0\n                -cullingOverride \"none\" \n                -lowQualityLighting 0\n                -maximumNumHardwareLights 0\n                -occlusionCulling 0\n                -shadingModel 0\n                -useBaseRenderer 0\n                -useReducedRenderer 0\n                -smallObjectCulling 0\n                -smallObjectThreshold -1 \n                -interactiveDisableShadows 0\n                -interactiveBackFaceCull 0\n                -sortTransparent 1\n                -nurbsCurves 1\n                -nurbsSurfaces 1\n"
		+ "                -polymeshes 1\n                -subdivSurfaces 1\n                -planes 1\n                -lights 1\n                -cameras 1\n                -controlVertices 1\n                -hulls 1\n                -grid 1\n                -imagePlane 1\n                -joints 1\n                -ikHandles 1\n                -deformers 1\n                -dynamics 1\n                -particleInstancers 1\n                -fluids 1\n                -hairSystems 1\n                -follicles 1\n                -nCloths 1\n                -nParticles 1\n                -nRigids 1\n                -dynamicConstraints 1\n                -locators 1\n                -manipulators 1\n                -pluginShapes 1\n                -dimensions 1\n                -handles 1\n                -pivots 1\n                -textures 1\n                -strokes 1\n                -motionTrails 1\n                -clipGhosts 1\n                -greasePencils 1\n                -shadows 0\n                -captureSequenceNumber -1\n                -width 0\n"
		+ "                -height 0\n                -sceneRenderFilter 0\n                -displayMode \"centerEye\" \n                -viewColor 0 0 0 1 \n                -useCustomBackground 1\n                $editorName;\n            stereoCameraView -e -viewSelected 0 $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"hyperShadePanel\" (localizedPanelLabel(\"Hypershade\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"hyperShadePanel\" -l (localizedPanelLabel(\"Hypershade\")) -mbv $menusOkayInPanels `;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Hypershade\")) -mbv $menusOkayInPanels  $panelName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\t$panelName = `sceneUIReplacement -getNextScriptedPanel \"nodeEditorPanel\" (localizedPanelLabel(\"Node Editor\")) `;\n\tif (\"\" == $panelName) {\n\t\tif ($useSceneConfig) {\n\t\t\t$panelName = `scriptedPanel -unParent  -type \"nodeEditorPanel\" -l (localizedPanelLabel(\"Node Editor\")) -mbv $menusOkayInPanels `;\n"
		+ "\t\t\t$editorName = ($panelName+\"NodeEditorEd\");\n            nodeEditor -e \n                -allAttributes 0\n                -allNodes 0\n                -autoSizeNodes 1\n                -consistentNameSize 1\n                -createNodeCommand \"nodeEdCreateNodeCommand\" \n                -defaultPinnedState 0\n                -additiveGraphingMode 0\n                -settingsChangedCallback \"nodeEdSyncControls\" \n                -traversalDepthLimit -1\n                -keyPressCommand \"nodeEdKeyPressCommand\" \n                -nodeTitleMode \"name\" \n                -gridSnap 0\n                -gridVisibility 1\n                -popupMenuScript \"nodeEdBuildPanelMenus\" \n                -showNamespace 1\n                -showShapes 1\n                -showSGShapes 0\n                -showTransforms 1\n                -useAssets 1\n                -syncedSelection 1\n                -extendToShapes 1\n                -activeTab -1\n                -editorMode \"default\" \n                $editorName;\n\t\t}\n\t} else {\n\t\t$label = `panel -q -label $panelName`;\n"
		+ "\t\tscriptedPanel -edit -l (localizedPanelLabel(\"Node Editor\")) -mbv $menusOkayInPanels  $panelName;\n\n\t\t\t$editorName = ($panelName+\"NodeEditorEd\");\n            nodeEditor -e \n                -allAttributes 0\n                -allNodes 0\n                -autoSizeNodes 1\n                -consistentNameSize 1\n                -createNodeCommand \"nodeEdCreateNodeCommand\" \n                -defaultPinnedState 0\n                -additiveGraphingMode 0\n                -settingsChangedCallback \"nodeEdSyncControls\" \n                -traversalDepthLimit -1\n                -keyPressCommand \"nodeEdKeyPressCommand\" \n                -nodeTitleMode \"name\" \n                -gridSnap 0\n                -gridVisibility 1\n                -popupMenuScript \"nodeEdBuildPanelMenus\" \n                -showNamespace 1\n                -showShapes 1\n                -showSGShapes 0\n                -showTransforms 1\n                -useAssets 1\n                -syncedSelection 1\n                -extendToShapes 1\n                -activeTab -1\n                -editorMode \"default\" \n"
		+ "                $editorName;\n\t\tif (!$useSceneConfig) {\n\t\t\tpanel -e -l $label $panelName;\n\t\t}\n\t}\n\n\n\tif ($useSceneConfig) {\n        string $configName = `getPanel -cwl (localizedPanelLabel(\"Current Layout\"))`;\n        if (\"\" != $configName) {\n\t\t\tpanelConfiguration -edit -label (localizedPanelLabel(\"Current Layout\")) \n\t\t\t\t-defaultImage \"vacantCell.xP:/\"\n\t\t\t\t-image \"\"\n\t\t\t\t-sc false\n\t\t\t\t-configString \"global string $gMainPane; paneLayout -e -cn \\\"vertical2\\\" -ps 1 30 100 -ps 2 70 100 $gMainPane;\"\n\t\t\t\t-removeAllPanels\n\t\t\t\t-ap false\n\t\t\t\t\t(localizedPanelLabel(\"Outliner\")) \n\t\t\t\t\t\"outlinerPanel\"\n"
		+ "\t\t\t\t\t\"$panelName = `outlinerPanel -unParent -l (localizedPanelLabel(\\\"Outliner\\\")) -mbv $menusOkayInPanels `;\\n$editorName = $panelName;\\noutlinerEditor -e \\n    -docTag \\\"isolOutln_fromSeln\\\" \\n    -showShapes 0\\n    -showReferenceNodes 1\\n    -showReferenceMembers 1\\n    -showAttributes 0\\n    -showConnected 0\\n    -showAnimCurvesOnly 0\\n    -showMuteInfo 0\\n    -organizeByLayer 1\\n    -showAnimLayerWeight 1\\n    -autoExpandLayers 1\\n    -autoExpand 0\\n    -showDagOnly 1\\n    -showAssets 1\\n    -showContainedOnly 1\\n    -showPublishedAsConnected 0\\n    -showContainerContents 1\\n    -ignoreDagHierarchy 0\\n    -expandConnections 0\\n    -showUpstreamCurves 1\\n    -showUnitlessCurves 1\\n    -showCompounds 1\\n    -showLeafs 1\\n    -showNumericAttrsOnly 0\\n    -highlightActive 1\\n    -autoSelectNewObjects 0\\n    -doNotSelectNewObjects 0\\n    -dropIsParent 1\\n    -transmitFilters 0\\n    -setFilter \\\"defaultSetFilter\\\" \\n    -showSetMembers 1\\n    -allowMultiSelection 1\\n    -alwaysToggleSelect 0\\n    -directSelect 0\\n    -displayMode \\\"DAG\\\" \\n    -expandObjects 0\\n    -setsIgnoreFilters 1\\n    -containersIgnoreFilters 0\\n    -editAttrName 0\\n    -showAttrValues 0\\n    -highlightSecondary 0\\n    -showUVAttrsOnly 0\\n    -showTextureNodesOnly 0\\n    -attrAlphaOrder \\\"default\\\" \\n    -animLayerFilterOptions \\\"allAffecting\\\" \\n    -sortOrder \\\"none\\\" \\n    -longNames 0\\n    -niceNames 1\\n    -showNamespace 1\\n    -showPinIcons 0\\n    -mapMotionTrails 0\\n    -ignoreHiddenAttribute 0\\n    -ignoreOutlinerColor 0\\n    $editorName\"\n"
		+ "\t\t\t\t\t\"outlinerPanel -edit -l (localizedPanelLabel(\\\"Outliner\\\")) -mbv $menusOkayInPanels  $panelName;\\n$editorName = $panelName;\\noutlinerEditor -e \\n    -docTag \\\"isolOutln_fromSeln\\\" \\n    -showShapes 0\\n    -showReferenceNodes 1\\n    -showReferenceMembers 1\\n    -showAttributes 0\\n    -showConnected 0\\n    -showAnimCurvesOnly 0\\n    -showMuteInfo 0\\n    -organizeByLayer 1\\n    -showAnimLayerWeight 1\\n    -autoExpandLayers 1\\n    -autoExpand 0\\n    -showDagOnly 1\\n    -showAssets 1\\n    -showContainedOnly 1\\n    -showPublishedAsConnected 0\\n    -showContainerContents 1\\n    -ignoreDagHierarchy 0\\n    -expandConnections 0\\n    -showUpstreamCurves 1\\n    -showUnitlessCurves 1\\n    -showCompounds 1\\n    -showLeafs 1\\n    -showNumericAttrsOnly 0\\n    -highlightActive 1\\n    -autoSelectNewObjects 0\\n    -doNotSelectNewObjects 0\\n    -dropIsParent 1\\n    -transmitFilters 0\\n    -setFilter \\\"defaultSetFilter\\\" \\n    -showSetMembers 1\\n    -allowMultiSelection 1\\n    -alwaysToggleSelect 0\\n    -directSelect 0\\n    -displayMode \\\"DAG\\\" \\n    -expandObjects 0\\n    -setsIgnoreFilters 1\\n    -containersIgnoreFilters 0\\n    -editAttrName 0\\n    -showAttrValues 0\\n    -highlightSecondary 0\\n    -showUVAttrsOnly 0\\n    -showTextureNodesOnly 0\\n    -attrAlphaOrder \\\"default\\\" \\n    -animLayerFilterOptions \\\"allAffecting\\\" \\n    -sortOrder \\\"none\\\" \\n    -longNames 0\\n    -niceNames 1\\n    -showNamespace 1\\n    -showPinIcons 0\\n    -mapMotionTrails 0\\n    -ignoreHiddenAttribute 0\\n    -ignoreOutlinerColor 0\\n    $editorName\"\n"
		+ "\t\t\t\t-ap false\n\t\t\t\t\t(localizedPanelLabel(\"Persp View\")) \n\t\t\t\t\t\"modelPanel\"\n"
		+ "\t\t\t\t\t\"$panelName = `modelPanel -unParent -l (localizedPanelLabel(\\\"Persp View\\\")) -mbv $menusOkayInPanels `;\\n$editorName = $panelName;\\nmodelEditor -e \\n    -cam `findStartUpCamera persp` \\n    -useInteractiveMode 0\\n    -displayLights \\\"default\\\" \\n    -displayAppearance \\\"smoothShaded\\\" \\n    -activeOnly 0\\n    -ignorePanZoom 0\\n    -wireframeOnShaded 1\\n    -headsUpDisplay 1\\n    -holdOuts 1\\n    -selectionHiliteDisplay 1\\n    -useDefaultMaterial 0\\n    -bufferMode \\\"double\\\" \\n    -twoSidedLighting 0\\n    -backfaceCulling 0\\n    -xray 0\\n    -jointXray 1\\n    -activeComponentsXray 0\\n    -displayTextures 0\\n    -smoothWireframe 0\\n    -lineWidth 1\\n    -textureAnisotropic 0\\n    -textureHilight 1\\n    -textureSampling 2\\n    -textureDisplay \\\"modulate\\\" \\n    -textureMaxSize 16384\\n    -fogging 0\\n    -fogSource \\\"fragment\\\" \\n    -fogMode \\\"linear\\\" \\n    -fogStart 0\\n    -fogEnd 100\\n    -fogDensity 0.1\\n    -fogColor 0.5 0.5 0.5 1 \\n    -depthOfFieldPreview 1\\n    -maxConstantTransparency 1\\n    -rendererName \\\"vp2Renderer\\\" \\n    -objectFilterShowInHUD 1\\n    -isFiltered 0\\n    -colorResolution 256 256 \\n    -bumpResolution 512 512 \\n    -textureCompression 0\\n    -transparencyAlgorithm \\\"frontAndBackCull\\\" \\n    -transpInShadows 0\\n    -cullingOverride \\\"none\\\" \\n    -lowQualityLighting 0\\n    -maximumNumHardwareLights 1\\n    -occlusionCulling 0\\n    -shadingModel 0\\n    -useBaseRenderer 0\\n    -useReducedRenderer 0\\n    -smallObjectCulling 0\\n    -smallObjectThreshold -1 \\n    -interactiveDisableShadows 0\\n    -interactiveBackFaceCull 0\\n    -sortTransparent 1\\n    -nurbsCurves 1\\n    -nurbsSurfaces 1\\n    -polymeshes 1\\n    -subdivSurfaces 1\\n    -planes 1\\n    -lights 1\\n    -cameras 1\\n    -controlVertices 1\\n    -hulls 1\\n    -grid 1\\n    -imagePlane 1\\n    -joints 1\\n    -ikHandles 1\\n    -deformers 1\\n    -dynamics 1\\n    -particleInstancers 1\\n    -fluids 1\\n    -hairSystems 1\\n    -follicles 1\\n    -nCloths 1\\n    -nParticles 1\\n    -nRigids 1\\n    -dynamicConstraints 1\\n    -locators 1\\n    -manipulators 1\\n    -pluginShapes 1\\n    -dimensions 1\\n    -handles 1\\n    -pivots 1\\n    -textures 1\\n    -strokes 1\\n    -motionTrails 1\\n    -clipGhosts 1\\n    -greasePencils 1\\n    -shadows 0\\n    -captureSequenceNumber -1\\n    -width 1028\\n    -height 712\\n    -sceneRenderFilter 0\\n    $editorName;\\nmodelEditor -e -viewSelected 0 $editorName\"\n"
		+ "\t\t\t\t\t\"modelPanel -edit -l (localizedPanelLabel(\\\"Persp View\\\")) -mbv $menusOkayInPanels  $panelName;\\n$editorName = $panelName;\\nmodelEditor -e \\n    -cam `findStartUpCamera persp` \\n    -useInteractiveMode 0\\n    -displayLights \\\"default\\\" \\n    -displayAppearance \\\"smoothShaded\\\" \\n    -activeOnly 0\\n    -ignorePanZoom 0\\n    -wireframeOnShaded 1\\n    -headsUpDisplay 1\\n    -holdOuts 1\\n    -selectionHiliteDisplay 1\\n    -useDefaultMaterial 0\\n    -bufferMode \\\"double\\\" \\n    -twoSidedLighting 0\\n    -backfaceCulling 0\\n    -xray 0\\n    -jointXray 1\\n    -activeComponentsXray 0\\n    -displayTextures 0\\n    -smoothWireframe 0\\n    -lineWidth 1\\n    -textureAnisotropic 0\\n    -textureHilight 1\\n    -textureSampling 2\\n    -textureDisplay \\\"modulate\\\" \\n    -textureMaxSize 16384\\n    -fogging 0\\n    -fogSource \\\"fragment\\\" \\n    -fogMode \\\"linear\\\" \\n    -fogStart 0\\n    -fogEnd 100\\n    -fogDensity 0.1\\n    -fogColor 0.5 0.5 0.5 1 \\n    -depthOfFieldPreview 1\\n    -maxConstantTransparency 1\\n    -rendererName \\\"vp2Renderer\\\" \\n    -objectFilterShowInHUD 1\\n    -isFiltered 0\\n    -colorResolution 256 256 \\n    -bumpResolution 512 512 \\n    -textureCompression 0\\n    -transparencyAlgorithm \\\"frontAndBackCull\\\" \\n    -transpInShadows 0\\n    -cullingOverride \\\"none\\\" \\n    -lowQualityLighting 0\\n    -maximumNumHardwareLights 1\\n    -occlusionCulling 0\\n    -shadingModel 0\\n    -useBaseRenderer 0\\n    -useReducedRenderer 0\\n    -smallObjectCulling 0\\n    -smallObjectThreshold -1 \\n    -interactiveDisableShadows 0\\n    -interactiveBackFaceCull 0\\n    -sortTransparent 1\\n    -nurbsCurves 1\\n    -nurbsSurfaces 1\\n    -polymeshes 1\\n    -subdivSurfaces 1\\n    -planes 1\\n    -lights 1\\n    -cameras 1\\n    -controlVertices 1\\n    -hulls 1\\n    -grid 1\\n    -imagePlane 1\\n    -joints 1\\n    -ikHandles 1\\n    -deformers 1\\n    -dynamics 1\\n    -particleInstancers 1\\n    -fluids 1\\n    -hairSystems 1\\n    -follicles 1\\n    -nCloths 1\\n    -nParticles 1\\n    -nRigids 1\\n    -dynamicConstraints 1\\n    -locators 1\\n    -manipulators 1\\n    -pluginShapes 1\\n    -dimensions 1\\n    -handles 1\\n    -pivots 1\\n    -textures 1\\n    -strokes 1\\n    -motionTrails 1\\n    -clipGhosts 1\\n    -greasePencils 1\\n    -shadows 0\\n    -captureSequenceNumber -1\\n    -width 1028\\n    -height 712\\n    -sceneRenderFilter 0\\n    $editorName;\\nmodelEditor -e -viewSelected 0 $editorName\"\n"
		+ "\t\t\t\t$configName;\n\n            setNamedPanelLayout (localizedPanelLabel(\"Current Layout\"));\n        }\n\n        panelHistory -e -clear mainPanelHistory;\n        setFocus `paneLayout -q -p1 $gMainPane`;\n        sceneUIReplacement -deleteRemaining;\n        sceneUIReplacement -clear;\n\t}\n\n\ngrid -spacing 50 -size 500 -divisions 1 -displayAxes yes -displayGridLines yes -displayDivisionLines yes -displayPerspectiveLabels yes -displayOrthographicLabels yes -displayAxesBold yes -perspectiveLabelPosition axis -orthographicLabelPosition axis;\nviewManip -drawCompass 0 -compassAngle 0 -frontParameters \"\" -homeParameters \"\" -selectionLockParameters \"\";\n}\n");
	setAttr ".st" 3;
createNode script -n "sceneConfigurationScriptNode";
	rename -uid "E16123ED-4BA4-875F-71B2-2A876A266B03";
	setAttr ".b" -type "string" "playbackOptions -min 0 -max 60 -ast 0 -aet 60 ";
	setAttr ".st" 6;
createNode animCurveTL -n "targetSkeletonAttachTo_JNT_translateZ";
	rename -uid "23AE2B66-4E82-EDAE-0BEB-F19B22C4FE7F";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr -s 6 ".ktv[0:5]"  0 0 4 38.187390089087863 15 100 30 0 45 -100
		 60 0;
	setAttr -s 6 ".kit[0:5]"  2 18 18 1 18 2;
	setAttr -s 6 ".kot[0:5]"  2 18 18 1 18 2;
	setAttr -s 6 ".kix[3:5]"  0.0031903854105621576 1 0.0049999374896287918;
	setAttr -s 6 ".kiy[3:5]"  -0.99999493360519409 0 0.99998748302459717;
	setAttr -s 6 ".kox[3:5]"  0.0031903842464089394 1 1;
	setAttr -s 6 ".koy[3:5]"  -0.99999493360519409 0 0;
createNode blinn -n "ponytail_SUB";
	rename -uid "D54B6020-431F-A66D-F629-DB9C95B0DAFE";
	addAttr -ci true -sn "physicalise" -ln "physicalise" -nn "Physicalize" -min 0 -max 
		4 -en "None:Default:ProxyNoDraw:NoCollide:Obstruct" -at "enum";
	setAttr ".c" -type "float3" 0 0.88461661 1 ;
createNode shadingEngine -n "blinn1SG";
	rename -uid "B52E3A45-4CDD-EA41-41DA-AD81770F8F71";
	setAttr ".ihi" 0;
	setAttr -s 2 ".dsm";
	setAttr ".ro" yes;
createNode materialInfo -n "materialInfo1";
	rename -uid "23E58E78-44F3-186A-FA72-16A83D55D6FE";
createNode nodeGraphEditorInfo -n "hyperShadePrimaryNodeEditorSavedTabsInfo";
	rename -uid "75DDE28C-42EB-F9C2-A77A-4081F636D3A3";
	setAttr ".tgi[0].tn" -type "string" "Untitled_1";
	setAttr ".tgi[0].vl" -type "double2" -197.61903976637254 -473.80950498202583 ;
	setAttr ".tgi[0].vh" -type "double2" 191.66665905051792 496.42855170227313 ;
	setAttr -s 2 ".tgi[0].ni";
	setAttr ".tgi[0].ni[0].x" 1.4285714626312256;
	setAttr ".tgi[0].ni[0].y" -1.4285714626312256;
	setAttr ".tgi[0].ni[0].nvs" 1923;
	setAttr ".tgi[0].ni[1].x" 262.85714721679687;
	setAttr ".tgi[0].ni[1].y" -114.28571319580078;
	setAttr ".tgi[0].ni[1].nvs" 1923;
createNode animCurveTL -n "targetSkeletonAttachTo_JNT_translateX";
	rename -uid "8DFDF362-41AD-C803-1C42-F0A5289A43F3";
	setAttr ".tan" 18;
	setAttr ".wgt" no;
	setAttr -s 10 ".ktv[0:9]"  0 320 4 328.44594610000416 7.5 350 15 320
		 22.5 350 30 320 37.5 350 45 320 52.5 350 60 320;
createNode animCurveTA -n "targetSkeletonAttachTo_JNT_rotateY";
	rename -uid "5EE0E8A9-481D-0916-0C6E-769E0566F612";
	setAttr ".tan" 2;
	setAttr ".wgt" no;
	setAttr -s 5 ".ktv[0:4]"  0 0 15 -20 30 0 45 20 60 0;
	setAttr -s 5 ".kit[1:4]"  18 2 18 2;
	setAttr -s 5 ".kot[1:4]"  18 2 18 2;
createNode polyCylinder -n "polyCylinder1";
	rename -uid "9BFA9288-4B9D-F4E0-70A8-2980E15C6D5E";
	setAttr ".r" 12;
	setAttr ".h" 350;
	setAttr ".sa" 16;
	setAttr ".sh" 8;
	setAttr ".sc" 1;
	setAttr ".cuv" 3;
createNode polyPlane -n "polyPlane1";
	rename -uid "02B4EA04-43AB-158E-4DAF-C895157F91CD";
	setAttr ".w" 50;
	setAttr ".h" 50;
	setAttr ".sw" 1;
	setAttr ".sh" 1;
	setAttr ".cuv" 2;
createNode polyTriangulate -n "polyTriangulate1";
	rename -uid "70747C93-44DE-BB9D-DBC0-FC9388824B4E";
	setAttr ".ics" -type "componentList" 1 "f[*]";
createNode deleteComponent -n "deleteComponent1";
	rename -uid "46BF4F4F-49A0-6E3B-77EE-A39E01B58E1E";
	setAttr ".dc" -type "componentList" 1 "f[0]";
createNode tweak -n "tweak2";
	rename -uid "0E268B3F-4572-0488-69DB-CDA46348321F";
	setAttr -s 3 ".vl[0].vt[0:2]" -type "float3"  10.355339 0 -25 -10.355339 
		0 25 -25 0 -10.355339;
createNode objectSet -n "tweakSet2";
	rename -uid "46BF7622-4A5D-D408-7AA6-2A98E714333B";
	setAttr ".ihi" 0;
	setAttr ".vo" yes;
createNode groupId -n "groupId4";
	rename -uid "9DCE8A0A-4702-8F8D-2C19-729824192551";
	setAttr ".ihi" 0;
createNode groupParts -n "groupParts4";
	rename -uid "49BAB0B7-4085-50A2-981E-D98406AC3CBD";
	setAttr ".ihi" 0;
	setAttr ".ic" -type "componentList" 1 "vtx[*]";
createNode skinCluster -n "skinCluster1";
	rename -uid "C37AB456-4E3E-C68F-D27A-F5B4C643CA96";
	setAttr ".skm" 1;
	setAttr -s 146 ".wl";
	setAttr -s 4 ".wl[0].w[3:6]"  0.00068327723300466931 0.013139514717235229 
		0.50985364798147303 0.47632356006828691;
	setAttr -s 4 ".wl[1].w[3:6]"  0.00068345496848463668 0.012736978246703324 
		0.51026255640870621 0.47631701037610585;
	setAttr -s 4 ".wl[2].w[3:6]"  0.00067896390066530773 0.012347378375768381 
		0.51064432897867895 0.47632932874488754;
	setAttr -s 4 ".wl[3].w[3:6]"  0.00067968030070678076 0.012435032942606745 
		0.5105616467957339 0.47632363996095262;
	setAttr -s 4 ".wl[4].w[3:6]"  0.00068336927471572377 0.01281923771069597 
		0.51018501060681942 0.47631238240776891;
	setAttr -s 4 ".wl[5].w[3:6]"  0.00068461098581852717 0.012709505362744284 
		0.5102951704098323 0.47631071324160473;
	setAttr -s 4 ".wl[6].w[3:6]"  0.00068358237767016778 0.012365775607822481 
		0.51063761248702877 0.4763130295274785;
	setAttr -s 4 ".wl[7].w[3:6]"  0.00068052189497697102 0.012680371675194495 
		0.51031080804837425 0.47632829838145418;
	setAttr -s 4 ".wl[8].w[3:6]"  0.00067922552816548898 0.012784034460047529 
		0.51020531173586259 0.47633142827592434;
	setAttr -s 4 ".wl[9].w[3:6]"  0.0006826313699767676 0.012456925631290151 
		0.51054962150596217 0.47631082149277099;
	setAttr -s 4 ".wl[10].w[3:6]"  0.00068223573326793205 0.012376772213292562 
		0.51062786842642516 0.47631312362701439;
	setAttr -s 4 ".wl[11].w[3:6]"  0.0006738735242263744 0.012668290941166867 
		0.5103007807722082 0.4763570547623987;
	setAttr -s 4 ".wl[12].w[3:6]"  0.00066857188273510622 0.013025429255844909 
		0.50991767982855352 0.47638831903286633;
	setAttr -s 4 ".wl[13].w[3:6]"  0.00066819878841224819 0.012594063016508075 
		0.51035391738158287 0.47638382081349684;
	setAttr -s 4 ".wl[14].w[3:6]"  0.00066759554549687997 0.012066872045235242 
		0.51088775860362867 0.47637777380563928;
	setAttr -s 4 ".wl[15].w[3:6]"  0.00067382736216754834 0.012643674363967048 
		0.51032481834973153 0.47635767992413386;
	setAttr -s 4 ".wl[16].w[3:6]"  0.0019321959199058998 0.076471102811570851 
		0.56427831258367167 0.35731838868485166;
	setAttr -s 4 ".wl[17].w[3:6]"  0.0017067701361867318 0.074165596508382531 
		0.56683646202827487 0.35729117132715593;
	setAttr -s 4 ".wl[18].w[3:6]"  0.0014777591089411685 0.073579690769697961 
		0.56767027227001998 0.35727227785134097;
	setAttr -s 4 ".wl[19].w[3:6]"  0.0014571238380655534 0.075009975940790341 
		0.5662658639598015 0.3572670362613426;
	setAttr -s 4 ".wl[20].w[3:6]"  0.0015852291642033745 0.075900893560635091 
		0.56523028796105113 0.35728358931411058;
	setAttr -s 4 ".wl[21].w[3:6]"  0.0016098112977916265 0.074103045784403673 
		0.56700424559210727 0.35728289732569729;
	setAttr -s 4 ".wl[22].w[3:6]"  0.0015327240451718362 0.07418101696236773 
		0.56699935626924902 0.35728690272321156;
	setAttr -s 4 ".wl[23].w[3:6]"  0.0016063993411563672 0.075844677607499758 
		0.56524967402582271 0.35729924902552118;
	setAttr -s 4 ".wl[24].w[3:6]"  0.0015800508372425838 0.074863560975923213 
		0.56628383809725691 0.35727255008957731;
	setAttr -s 4 ".wl[25].w[3:6]"  0.0014580492354757516 0.073641055780779979 
		0.5676477473424929 0.35725314764125143;
	setAttr -s 4 ".wl[26].w[3:6]"  0.0014807436263050244 0.074416548237061272 
		0.5668128040966014 0.3572899040400323;
	setAttr -s 4 ".wl[27].w[3:6]"  0.0017040632184574416 0.076643739814156342 
		0.56429567943443704 0.35735651753294906;
	setAttr -s 4 ".wl[28].w[3:6]"  0.0019228676244503985 0.076501922076403606 
		0.56421259060726259 0.35736261969188327;
	setAttr -s 4 ".wl[29].w[3:6]"  0.0017245709504787078 0.073295301527278714 
		0.5676600858505928 0.35732004167164988;
	setAttr -s 4 ".wl[30].w[3:6]"  0.0014900226173145759 0.073561016054631514 
		0.56763265245223105 0.357316308875823;
	setAttr -s 4 ".wl[31].w[3:6]"  0.0017347701961819965 0.076768217411715883 
		0.56416404973964696 0.35733296265245523;
	setAttr -s 4 ".wl[32].w[3:6]"  0.048858541006657388 0.29181346835844629 
		0.51845376792760356 0.14087422270729277;
	setAttr -s 4 ".wl[33].w[3:6]"  0.047543440309990248 0.28994855765119909 
		0.5217050036104327 0.14080299842837801;
	setAttr -s 4 ".wl[34].w[3:6]"  0.04695515398970989 0.29131392390426314 
		0.52095735981002633 0.14077356229600052;
	setAttr -s 4 ".wl[35].w[3:6]"  0.047273200867664629 0.29367252904501284 
		0.5182541602713866 0.14080010981593602;
	setAttr -s 4 ".wl[36].w[3:6]"  0.047750327827600331 0.2924049122260739 
		0.51901753778434423 0.14082722216198168;
	setAttr -s 4 ".wl[37].w[3:6]"  0.047473242194470376 0.2901652527857157 
		0.5215434322601058 0.14081807275970806;
	setAttr -s 4 ".wl[38].w[3:6]"  0.047510981896607206 0.29266354409372464 
		0.51899853417454045 0.14082693983512784;
	setAttr -s 4 ".wl[39].w[3:6]"  0.047724570256762501 0.29313758117516941 
		0.51832829700118399 0.14080955156688399;
	setAttr -s 4 ".wl[40].w[3:6]"  0.047201839133128136 0.29104139895009196 
		0.52098241509774679 0.14077434681903317;
	setAttr -s 4 ".wl[41].w[3:6]"  0.046977804698790024 0.29064447103436564 
		0.52159101372971639 0.1407867105371281;
	setAttr -s 4 ".wl[42].w[3:6]"  0.047672116624501916 0.29319409539418956 
		0.51827438159594297 0.14085940638536543;
	setAttr -s 4 ".wl[43].w[3:6]"  0.04897423494577801 0.29476869585742244 
		0.51533587965486682 0.14092118954193275;
	setAttr -s 4 ".wl[44].w[3:6]"  0.048986595165359026 0.29122289897893822 
		0.51890834497001836 0.14088216088568437;
	setAttr -s 4 ".wl[45].w[3:6]"  0.047611118145234742 0.28861585861029559 
		0.52294977707902357 0.14082324616544623;
	setAttr -s 4 ".wl[46].w[3:6]"  0.047739945066178964 0.29267647593573126 
		0.51872100247908903 0.14086257651900069;
	setAttr -s 4 ".wl[47].w[3:6]"  0.049096555551382488 0.29465330975229354 
		0.51533651663711966 0.14091361805920435;
	setAttr -s 4 ".wl[48].w[2:5]"  0.041984505365290088 0.25784252649519507 
		0.46514791063153599 0.23502505750797881;
	setAttr -s 4 ".wl[49].w[2:5]"  0.041852700553647919 0.25626812108873964 
		0.46619647921449775 0.23568269914311468;
	setAttr -s 4 ".wl[50].w[2:5]"  0.041898680800680418 0.25612856945784923 
		0.46775298445882685 0.23421976528264346;
	setAttr -s 4 ".wl[51].w[2:5]"  0.041979351962036886 0.25691136336914427 
		0.4678628218026844 0.23324646286613451;
	setAttr -s 4 ".wl[52].w[2:5]"  0.041959765571300198 0.25702663301873302 
		0.46592646038363805 0.23508714102632888;
	setAttr -s 4 ".wl[53].w[2:5]"  0.041866406260855228 0.25664714398405325 
		0.46643121543081484 0.23505523432427677;
	setAttr -s 4 ".wl[54].w[2:5]"  0.041949846076616101 0.25707855765674481 
		0.46767763602663603 0.23329396024000304;
	setAttr -s 4 ".wl[55].w[2:5]"  0.041927313126367799 0.25672375389387597 
		0.46704575670607867 0.23430317627367755;
	setAttr -s 4 ".wl[56].w[2:5]"  0.041838704372998171 0.25609110484454561 
		0.46644101615709682 0.2356291746253594;
	setAttr -s 4 ".wl[57].w[2:5]"  0.041928894718187601 0.25645018329461905 
		0.4667998648903578 0.23482105709683548;
	setAttr -s 4 ".wl[58].w[2:5]"  0.042108724264559867 0.25818251474790455 
		0.46728352727868505 0.23242523370885051;
	setAttr -s 4 ".wl[59].w[2:5]"  0.042229463606560672 0.25940356107145118 
		0.46590029898349078 0.23246667633849749;
	setAttr -s 4 ".wl[60].w[2:5]"  0.042010008831904012 0.25802526721619723 
		0.4641249142220204 0.23583980972987825;
	setAttr -s 4 ".wl[61].w[2:5]"  0.041841355322686249 0.25684643420652381 
		0.46562724329411281 0.23568496717667717;
	setAttr -s 4 ".wl[62].w[2:5]"  0.042104735306811476 0.25840943529345894 
		0.46715974104339503 0.23232608835633453;
	setAttr -s 4 ".wl[63].w[2:5]"  0.042228950576672968 0.25937301775088001 
		0.46582251098560362 0.23257552068684342;
	setAttr -s 4 ".wl[64].w[2:5]"  0.24936135107761701 0.4625909971999197 
		0.25069125000533443 0.037356401717128951;
	setAttr -s 4 ".wl[65].w[2:5]"  0.25004226808457319 0.46172796809513583 
		0.25102169559945098 0.037208068220839934;
	setAttr -s 4 ".wl[66].w[1:4]"  0.037284942774573185 0.25030927200306252 
		0.46148775730775304 0.25091802791461121;
	setAttr -s 4 ".wl[67].w[1:4]"  0.037227756831641548 0.25030886537789343 
		0.46190551727705348 0.25055786051341156;
	setAttr -s 4 ".wl[68].w[2:5]"  0.25010097675227838 0.46189755249146364 
		0.25063816416621526 0.037363306590042764;
	setAttr -s 4 ".wl[69].w[2:5]"  0.25016235323553959 0.46193186176797807 
		0.25090016894573725 0.037005616050745024;
	setAttr -s 4 ".wl[70].w[1:4]"  0.037362150442355704 0.24989563183116459 
		0.46189811024131033 0.25084410748516933;
	setAttr -s 4 ".wl[71].w[2:5]"  0.24994700498775876 0.46190510744046143 
		0.25091925525955899 0.037228632312220851;
	setAttr -s 4 ".wl[72].w[2:5]"  0.25045159414766127 0.46148746792524359 
		0.25077538947682915 0.03728554845026584;
	setAttr -s 4 ".wl[73].w[1:4]"  0.037207461077356833 0.25056236869507492 
		0.46172826165286174 0.25050190857470639;
	setAttr -s 4 ".wl[74].w[1:4]"  0.037355697263644891 0.25015676762017974 
		0.46259134590745571 0.24989618920871973;
	setAttr -s 4 ".wl[75].w[2:5]"  0.24948895135251467 0.46344717178338757 
		0.24991948343019016 0.037144393433907547;
	setAttr -s 4 ".wl[76].w[2:5]"  0.24926615154202653 0.46271211686486607 
		0.25045434319831933 0.03756738839478805;
	setAttr -s 4 ".wl[77].w[2:5]"  0.2500973628833485 0.46231704658451139 
		0.25057731458294169 0.037008275949198338;
	setAttr -s 4 ".wl[78].w[1:4]"  0.037566671966582706 0.24991207048514066 
		0.46271246391418536 0.24980879363409134;
	setAttr -s 4 ".wl[79].w[1:4]"  0.037143594292454001 0.24932291970353393 
		0.46344755303622776 0.25008593296778431;
	setAttr -s 4 ".wl[80].w[1:4]"  0.2297005549003138 0.46867600983527041 
		0.25909970100154817 0.042523734262867444;
	setAttr -s 4 ".wl[81].w[1:4]"  0.23094452639582905 0.46892412171874048 
		0.25775010387725006 0.042381248008180397;
	setAttr -s 4 ".wl[82].w[1:4]"  0.23126488982830976 0.46882252508858924 
		0.25755379171328208 0.042358793369818903;
	setAttr -s 4 ".wl[83].w[1:4]"  0.22998413832782974 0.46929614645861811 
		0.25817224608681566 0.04254746912673648;
	setAttr -s 4 ".wl[84].w[1:4]"  0.22923153670300125 0.46974846304362911 
		0.25844112957448917 0.042578870678880366;
	setAttr -s 4 ".wl[85].w[1:4]"  0.23141288507076802 0.46824529885049371 
		0.25786959337793192 0.042472222700806209;
	setAttr -s 4 ".wl[86].w[1:4]"  0.23158863711914027 0.46767377048878106 
		0.25820256540572251 0.042535026986356056;
	setAttr -s 4 ".wl[87].w[1:4]"  0.22959528028918885 0.46980934200713886 
		0.25813512724695159 0.042460250456720708;
	setAttr -s 4 ".wl[88].w[1:4]"  0.230161721968867 0.46999138542055513 
		0.25748625197151287 0.042360640639065014;
	setAttr -s 4 ".wl[89].w[1:4]"  0.23137165325406586 0.46855965024445856 
		0.25771395658414636 0.042354739917329375;
	setAttr -s 4 ".wl[90].w[1:4]"  0.23065683587094965 0.46748705523407291 
		0.25931537225129031 0.042540736643686947;
	setAttr -s 4 ".wl[91].w[1:4]"  0.22868915101080683 0.46786016774574535 
		0.26068720717341526 0.04276347407003258;
	setAttr -s 4 ".wl[92].w[1:4]"  0.22960314616194372 0.46854799610729286 
		0.25932670888979692 0.042522148840966403;
	setAttr -s 4 ".wl[93].w[1:4]"  0.23298289667618477 0.46700472023943218 
		0.25775510837787258 0.042257274706510438;
	setAttr -s 4 ".wl[94].w[1:4]"  0.2325420116821863 0.46580685207932049 
		0.25913945422290124 0.042511682015592078;
	setAttr -s 4 ".wl[95].w[1:4]"  0.22975513411664725 0.46722970690264187 
		0.26032062411607954 0.042694534864631505;
	setAttr -s 4 ".wl[96].w[0:3]"  0.18633620050044489 0.47330592494700491 
		0.29272459201532802 0.04763328253722212;
	setAttr -s 4 ".wl[97].w[0:3]"  0.19276728461151454 0.47012620975301644 
		0.29016871677832473 0.046937788857144183;
	setAttr -s 4 ".wl[98].w[0:3]"  0.19405768173575971 0.46822171466049672 
		0.29055783066228419 0.04716277294145934;
	setAttr -s 4 ".wl[99].w[0:3]"  0.19308545015873513 0.46657741911026956 
		0.29265033610908081 0.047686794621914483;
	setAttr -s 4 ".wl[100].w[0:3]"  0.19037137986484326 0.4699792304775201 
		0.29217651966539165 0.047472869992245058;
	setAttr -s 4 ".wl[101].w[0:3]"  0.18826946146710957 0.474621735295508 
		0.28967393658796309 0.047434866649419295;
	setAttr -s 4 ".wl[102].w[0:3]"  0.18827606007023331 0.47208984958161232 
		0.2919227613048524 0.047711329043301914;
	setAttr -s 4 ".wl[103].w[0:3]"  0.19034350923296431 0.46922174543822165 
		0.29320134635733958 0.047233398971474438;
	setAttr -s 4 ".wl[104].w[0:3]"  0.19304574568970762 0.46919349738000471 
		0.29084497591429403 0.046915781015993502;
	setAttr -s 4 ".wl[105].w[0:3]"  0.19408501432730552 0.46893558350700543 
		0.28947477289780238 0.047504629267886685;
	setAttr -s 4 ".wl[106].w[0:3]"  0.19286180746374695 0.46699195404028715 
		0.29132679270979245 0.048819445786173525;
	setAttr -s 4 ".wl[107].w[0:3]"  0.1863919494415083 0.47038230105871021 
		0.29416874564274242 0.049057003857038914;
	setAttr -s 4 ".wl[108].w[0:3]"  0.18127092791480956 0.47882079135391098 
		0.29220712652546144 0.047701154205818053;
	setAttr -s 4 ".wl[109].w[0:3]"  0.18438079598522553 0.47990087118658847 
		0.28814508549108103 0.047573247337105037;
	setAttr -s 4 ".wl[110].w[0:3]"  0.1844393774276081 0.47586664001017198 
		0.29074517607979183 0.048948806482428137;
	setAttr -s 4 ".wl[111].w[0:3]"  0.18133083275834094 0.4754344576947187 
		0.29429834102290686 0.048936368524033574;
	setAttr -s 4 ".wl[112].w[0:3]"  0.52209882320591205 0.40473449145833412 
		0.071921980936538565 0.0012447043992153736;
	setAttr -s 4 ".wl[113].w[0:3]"  0.52889713104566649 0.39875881251966266 
		0.071125318662625461 0.0012187377720454383;
	setAttr -s 4 ".wl[114].w[0:3]"  0.52890682185258142 0.39738011493760561 
		0.072369805872596157 0.0013432573372169296;
	setAttr -s 4 ".wl[115].w[0:3]"  0.52552760167295975 0.39974016667428564 
		0.073361308151309951 0.0013709235014446556;
	setAttr -s 4 ".wl[116].w[0:3]"  0.52064613260047221 0.40637647620952322 
		0.071682221057366199 0.0012951701326384191;
	setAttr -s 4 ".wl[117].w[0:3]"  0.51884422465383107 0.40818824481058025 
		0.071596385505326501 0.001371145030262093;
	setAttr -s 4 ".wl[118].w[0:3]"  0.52064529571936147 0.4046148958012511 
		0.073393268154627808 0.0013465403247596779;
	setAttr -s 4 ".wl[119].w[0:3]"  0.52550480233294461 0.40076511450498659 
		0.072510518856002612 0.001219564306066278;
	setAttr -s 4 ".wl[120].w[0:3]"  0.52890319338507918 0.39875840959467795 
		0.071096114518653691 0.0012422825015891922;
	setAttr -s 4 ".wl[121].w[0:3]"  0.52892542228084205 0.39793628723102376 
		0.071668427442766566 0.0014698630453676656;
	setAttr -s 4 ".wl[122].w[0:3]"  0.52214686189006221 0.40221061856343376 
		0.073949818748341847 0.0016927007981621125;
	setAttr -s 4 ".wl[123].w[0:3]"  0.50976587052534461 0.41446325529300204 
		0.074272191219699246 0.0014986829619540833;
	setAttr -s 4 ".wl[124].w[0:3]"  0.50846031447239248 0.41916947316628878 
		0.071110516166037988 0.0012596961952809024;
	setAttr -s 4 ".wl[125].w[0:3]"  0.51325460586787808 0.41440354021730541 
		0.070847318574535634 0.0014945353402807675;
	setAttr -s 4 ".wl[126].w[0:3]"  0.50850846344026435 0.41574508110171837 
		0.074053635924173619 0.0016928195338436975;
	setAttr -s 4 ".wl[127].w[0:3]"  0.50976029918500287 0.4145740075042722 
		0.074192000491857438 0.001473692818867621;
	setAttr -s 4 ".wl[128].w[0:3]"  0.72752747506377546 0.26507898555489723 
		0.0072118414619440326 0.00018169791938315756;
	setAttr -s 4 ".wl[129].w[0:3]"  0.72895427294064719 0.26357513731863513 
		0.0072891352554593329 0.0001814544852584154;
	setAttr -s 4 ".wl[130].w[0:3]"  0.7278927759274233 0.26427899560328871 
		0.0076463374893505553 0.00018189097993758521;
	setAttr -s 4 ".wl[131].w[0:3]"  0.7252078145013432 0.26707396664221211 
		0.0075359153485744495 0.00018230350787027115;
	setAttr -s 4 ".wl[132].w[0:3]"  0.72309024590998239 0.26952989355100077 
		0.0071976432534197081 0.00018221728559714682;
	setAttr -s 4 ".wl[133].w[0:3]"  0.72308860708381462 0.26919480593706524 
		0.007534260253867925 0.00018232672525230934;
	setAttr -s 4 ".wl[134].w[0:3]"  0.72519754692484484 0.26697003331382479 
		0.0076504298334136647 0.00018198992791672406;
	setAttr -s 4 ".wl[135].w[0:3]"  0.72788898094067789 0.26463896683116456 
		0.0072905863956746041 0.00018146583248298474;
	setAttr -s 4 ".wl[136].w[0:3]"  0.72895844886638805 0.26365097909769025 
		0.0072089637899437741 0.00018160824597798151;
	setAttr -s 4 ".wl[137].w[0:3]"  0.72754420187794078 0.26470737830610319 
		0.0075662254801735426 0.0001821943357824363;
	setAttr -s 4 ".wl[138].w[0:3]"  0.72108031829703867 0.27076473695686915 
		0.0079722685195902677 0.00018267622650187099;
	setAttr -s 4 ".wl[139].w[0:3]"  0.71615489708412672 0.27611624943056146 
		0.0075466034540751193 0.00018225003123688359;
	setAttr -s 4 ".wl[140].w[0:3]"  0.71902695996659627 0.27377723196574094 
		0.0070141157778914644 0.0001816922897711943;
	setAttr -s 4 ".wl[141].w[0:3]"  0.71904669348117156 0.2732310785534442 
		0.0075400833575650309 0.00018214460781928158;
	setAttr -s 4 ".wl[142].w[0:3]"  0.71615989466753494 0.27568529008614584 
		0.007972157807000101 0.00018265743931898041;
	setAttr -s 4 ".wl[143].w[0:3]"  0.72105041186254359 0.27119638713389721 
		0.0075709126126007826 0.00018228839095853634;
	setAttr -s 4 ".wl[144].w[3:6]"  0.00081076832807261141 0.008763417801486326 
		0.49521291429902353 0.49521289957141762;
	setAttr -s 4 ".wl[145].w[0:3]"  0.74823284035543658 0.24848513080327753 
		0.0030301871053807039 0.00025184173590510762;
	setAttr -s 7 ".pm";
	setAttr ".pm[0]" -type "matrix" -2.2204460492503131e-016 1 0 -0 -1 -2.2204460492503131e-016 -0 0
		 0 -0 1 -0 500 1.7508840362920771e-013 1.4210854715202029e-014 1;
	setAttr ".pm[1]" -type "matrix" -2.2204460492503131e-016 1 0 0 -1 -2.2204460492503131e-016 0 0
		 0 -0 1 -0 450 1.8475397804224823e-013 1.4210854715202029e-014 1;
	setAttr ".pm[2]" -type "matrix" -2.2204460492503131e-016 1 0 0 -1 -2.2204460492503131e-016 0 0
		 0 -0 1 -0 400 1.9852009917597261e-013 7.1054273576010271e-015 1;
	setAttr ".pm[3]" -type "matrix" -2.2204460492503131e-016 1 0 0 -1 -2.2204460492503131e-016 0 0
		 0 -0 1 -0 350 2.0906436217201684e-013 7.1054273576010271e-015 1;
	setAttr ".pm[4]" -type "matrix" -2.2204460492503131e-016 1 0 0 -1 -2.2204460492503131e-016 0 0
		 0 -0 1 -0 300 2.2048731375106475e-013 1.3981177326982674e-013 1;
	setAttr ".pm[5]" -type "matrix" -2.2204460492503131e-016 1 0 0 -1 -2.2204460492503131e-016 0 0
		 0 -0 1 -0 250.00000000000006 2.3046089597752208e-013 1.2202738819411254e-013 1;
	setAttr ".pm[6]" -type "matrix" -2.2204460492503131e-016 1 0 0 -1 -2.2204460492503131e-016 0 0
		 0 -0 1 -0 200.00000000000006 2.4178546153412187e-013 8.9317442331093818e-014 1;
	setAttr ".gm" -type "matrix" 1 0 0 0 0 1 0 0 0 0 1 0 0 325 0 1;
	setAttr -s 7 ".ma";
	setAttr -s 7 ".dpf[0:6]"  4 4 4 4 4 4 4;
	setAttr -s 7 ".lw";
	setAttr -s 7 ".lw";
	setAttr ".mmi" yes;
	setAttr ".mi" 4;
	setAttr ".bm" 3;
	setAttr ".ucm" yes;
	setAttr ".wd" 1;
	setAttr -s 7 ".ifcl";
	setAttr -s 7 ".ifcl";
createNode tweak -n "tweak3";
	rename -uid "AFBC48D6-42D9-8BD0-F172-BD8FA4262688";
createNode objectSet -n "skinCluster1Set";
	rename -uid "F4340E97-48E4-D8E3-DF42-E0B0A036D97E";
	setAttr ".ihi" 0;
	setAttr ".vo" yes;
createNode groupId -n "skinCluster1GroupId";
	rename -uid "B3675DA3-4F88-7D0B-4DB2-07ADAC48A2AC";
	setAttr ".ihi" 0;
createNode groupParts -n "skinCluster1GroupParts";
	rename -uid "BD8E4482-443E-DE45-45D7-CFBD3A85D8A9";
	setAttr ".ihi" 0;
	setAttr ".ic" -type "componentList" 1 "vtx[*]";
createNode objectSet -n "tweakSet3";
	rename -uid "31C848B9-4B83-BC0A-8D23-B9AB2A1C330D";
	setAttr ".ihi" 0;
	setAttr ".vo" yes;
createNode groupId -n "groupId6";
	rename -uid "438F9884-4E07-7E4C-D265-A6A21C210FD3";
	setAttr ".ihi" 0;
createNode groupParts -n "groupParts6";
	rename -uid "C506B939-4DB6-3695-27A8-ABA50D3DAC04";
	setAttr ".ihi" 0;
	setAttr ".ic" -type "componentList" 1 "vtx[*]";
createNode dagPose -n "bindPose1";
	rename -uid "FE8302AE-4D5B-10C2-F7D4-C290FEAD4709";
	setAttr -s 7 ".wm";
	setAttr -s 7 ".xm";
	setAttr ".xm[0]" -type "matrix" "xform" 1 1 1 0 0 0 0 -6.4066101166692052e-014
		 500 -1.4210854715202029e-014 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 -0.70710678118654757 0.70710678118654746 1
		 1 1 yes;
	setAttr ".xm[1]" -type "matrix" "xform" 1 1 1 0 0 0 0 50 -9.6655744130405348e-015
		 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 1 1 1 yes;
	setAttr ".xm[2]" -type "matrix" "xform" 1 1 1 0 0 0 0 50 -1.376612113372438e-014
		 7.1054273576010019e-015 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 1 1 1 yes;
	setAttr ".xm[3]" -type "matrix" "xform" 1 1 1 0 0 0 0 50 -1.0544262996044242e-014
		 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 1 1 1 yes;
	setAttr ".xm[4]" -type "matrix" "xform" 1 1 1 0 0 0 0 49.999999999999993 -1.1422951579047908e-014
		 -1.3270634591222572e-013 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 1 1 1 yes;
	setAttr ".xm[5]" -type "matrix" "xform" 1 1 1 0 0 0 0 49.99999999999995 -9.9735822264573292e-015
		 1.7784385075714207e-014 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 1 1 1 yes;
	setAttr ".xm[6]" -type "matrix" "xform" 1 1 1 0 0 0 0 50.000000000000007 -1.1324565556599799e-014
		 3.2709945863018725e-014 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 1 1 1 yes;
	setAttr -s 7 ".m";
	setAttr -s 7 ".p";
	setAttr ".bp" yes;
createNode geomBind -n "geomBind1";
	rename -uid "1734EAF6-4DE3-E461-B51D-0EAB867F849F";
	setAttr ".fo" 0.05;
	setAttr ".mi" 4;
	setAttr ".gvr" 512;
select -ne :time1;
	setAttr ".o" 0;
select -ne :hardwareRenderingGlobals;
	setAttr ".otfna" -type "stringArray" 22 "NURBS Curves" "NURBS Surfaces" "Polygons" "Subdiv Surface" "Particles" "Particle Instance" "Fluids" "Strokes" "Image Planes" "UI" "Lights" "Cameras" "Locators" "Joints" "IK Handles" "Deformers" "Motion Trails" "Components" "Hair Systems" "Follicles" "Misc. UI" "Ornaments"  ;
	setAttr ".otfva" -type "Int32Array" 22 0 1 1 1 1 1
		 1 1 1 0 0 0 0 0 0 0 0 0
		 0 0 0 0 ;
	setAttr ".fprt" yes;
select -ne :renderPartition;
	setAttr -s 3 ".st";
select -ne :renderGlobalsList1;
select -ne :defaultShaderList1;
	setAttr -s 5 ".s";
select -ne :postProcessList1;
	setAttr -s 2 ".p";
select -ne :defaultRenderingList1;
select -ne :initialShadingGroup;
	setAttr ".ro" yes;
select -ne :initialParticleSE;
	setAttr ".ro" yes;
select -ne :defaultRenderGlobals;
	setAttr ".mcfr" 30;
select -ne :defaultResolution;
	setAttr ".pa" 1;
select -ne :hardwareRenderGlobals;
	setAttr ".ctrs" 256;
	setAttr ".btrs" 512;
	setAttr ".hwfr" 30;
select -ne :ikSystem;
	setAttr ".gsv" no;
	setAttr -s 4 ".sol";
connectAttr "groupId4.id" "ponytail_SKELShape.iog.og[1].gid";
connectAttr "tweakSet2.mwc" "ponytail_SKELShape.iog.og[1].gco";
connectAttr "tweak2.og[0]" "ponytail_SKELShape.i";
connectAttr "tweak2.vl[0].vt[0]" "ponytail_SKELShape.twl";
connectAttr "deleteComponent1.og" "ponytail_SKELShapeOrig.i";
connectAttr "targetSkeletonRoot_JNT.s" "targetSkeletonPelvis_JNT.is";
connectAttr "targetSkeletonPelvis_JNT.s" "targetSkeletonAttachTo_JNT.is";
connectAttr "targetSkeletonAttachTo_JNT_translateX.o" "targetSkeletonAttachTo_JNT.tx"
		;
connectAttr "targetSkeletonAttachTo_JNT_translateZ.o" "targetSkeletonAttachTo_JNT.tz"
		;
connectAttr "targetSkeletonAttachTo_JNT_rotateY.o" "targetSkeletonAttachTo_JNT.ry"
		;
connectAttr "targetSkeletonAttachTo_JNT.s" "sim_ponytail01_Zero_JNT.is";
connectAttr "skinCluster1.og[0]" "ponytail_MSHShape.i";
connectAttr "skinCluster1GroupId.id" "ponytail_MSHShape.iog.og[2].gid";
connectAttr "skinCluster1Set.mwc" "ponytail_MSHShape.iog.og[2].gco";
connectAttr "groupId6.id" "ponytail_MSHShape.iog.og[3].gid";
connectAttr "tweakSet3.mwc" "ponytail_MSHShape.iog.og[3].gco";
connectAttr "tweak3.vl[0].vt[0]" "ponytail_MSHShape.twl";
connectAttr "polyCylinder1.out" "ponytail_MSHShapeOrig.i";
connectAttr "sim_ponytail01_JNT.s" "sim_ponytail02_JNT.is";
connectAttr "sim_ponytail02_JNT.s" "sim_ponytail03_JNT.is";
connectAttr "sim_ponytail03_JNT.s" "sim_ponytail04_JNT.is";
connectAttr "sim_ponytail04_JNT.s" "sim_ponytail05_JNT.is";
connectAttr "sim_ponytail05_JNT.s" "sim_ponytail06_JNT.is";
connectAttr "sim_ponytail06_JNT.s" "sim_ponytail07_JNT.is";
connectAttr "sim_ponytail07_JNT.s" "sim_ponytail_END_JNT.is";
relationship "link" ":lightLinker1" ":initialShadingGroup.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" ":initialParticleSE.message" ":defaultLightSet.message";
relationship "link" ":lightLinker1" "blinn1SG.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" ":initialShadingGroup.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" ":initialParticleSE.message" ":defaultLightSet.message";
relationship "shadowLink" ":lightLinker1" "blinn1SG.message" ":defaultLightSet.message";
connectAttr "layerManager.dli[0]" "defaultLayer.id";
connectAttr "renderLayerManager.rlmi[0]" "defaultRenderLayer.rlid";
connectAttr "ponytail_SUB.oc" "blinn1SG.ss";
connectAttr "ponytail_MSHShape.iog" "blinn1SG.dsm" -na;
connectAttr "ponytail_SKELShape.iog" "blinn1SG.dsm" -na;
connectAttr "blinn1SG.msg" "materialInfo1.sg";
connectAttr "ponytail_SUB.msg" "materialInfo1.m";
connectAttr "ponytail_SUB.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[0].dn"
		;
connectAttr "blinn1SG.msg" "hyperShadePrimaryNodeEditorSavedTabsInfo.tgi[0].ni[1].dn"
		;
connectAttr "polyPlane1.out" "polyTriangulate1.ip";
connectAttr "polyTriangulate1.out" "deleteComponent1.ig";
connectAttr "groupParts4.og" "tweak2.ip[0].ig";
connectAttr "groupId4.id" "tweak2.ip[0].gi";
connectAttr "groupId4.msg" "tweakSet2.gn" -na;
connectAttr "ponytail_SKELShape.iog.og[1]" "tweakSet2.dsm" -na;
connectAttr "tweak2.msg" "tweakSet2.ub[0]";
connectAttr "ponytail_SKELShapeOrig.w" "groupParts4.ig";
connectAttr "groupId4.id" "groupParts4.gi";
connectAttr "skinCluster1GroupParts.og" "skinCluster1.ip[0].ig";
connectAttr "skinCluster1GroupId.id" "skinCluster1.ip[0].gi";
connectAttr "bindPose1.msg" "skinCluster1.bp";
connectAttr "sim_ponytail01_JNT.wm" "skinCluster1.ma[0]";
connectAttr "sim_ponytail02_JNT.wm" "skinCluster1.ma[1]";
connectAttr "sim_ponytail03_JNT.wm" "skinCluster1.ma[2]";
connectAttr "sim_ponytail04_JNT.wm" "skinCluster1.ma[3]";
connectAttr "sim_ponytail05_JNT.wm" "skinCluster1.ma[4]";
connectAttr "sim_ponytail06_JNT.wm" "skinCluster1.ma[5]";
connectAttr "sim_ponytail07_JNT.wm" "skinCluster1.ma[6]";
connectAttr "sim_ponytail01_JNT.liw" "skinCluster1.lw[0]";
connectAttr "sim_ponytail02_JNT.liw" "skinCluster1.lw[1]";
connectAttr "sim_ponytail03_JNT.liw" "skinCluster1.lw[2]";
connectAttr "sim_ponytail04_JNT.liw" "skinCluster1.lw[3]";
connectAttr "sim_ponytail05_JNT.liw" "skinCluster1.lw[4]";
connectAttr "sim_ponytail06_JNT.liw" "skinCluster1.lw[5]";
connectAttr "sim_ponytail07_JNT.liw" "skinCluster1.lw[6]";
connectAttr "sim_ponytail01_JNT.obcc" "skinCluster1.ifcl[0]";
connectAttr "sim_ponytail02_JNT.obcc" "skinCluster1.ifcl[1]";
connectAttr "sim_ponytail03_JNT.obcc" "skinCluster1.ifcl[2]";
connectAttr "sim_ponytail04_JNT.obcc" "skinCluster1.ifcl[3]";
connectAttr "sim_ponytail05_JNT.obcc" "skinCluster1.ifcl[4]";
connectAttr "sim_ponytail06_JNT.obcc" "skinCluster1.ifcl[5]";
connectAttr "sim_ponytail07_JNT.obcc" "skinCluster1.ifcl[6]";
connectAttr "geomBind1.scs" "skinCluster1.gb";
connectAttr "groupParts6.og" "tweak3.ip[0].ig";
connectAttr "groupId6.id" "tweak3.ip[0].gi";
connectAttr "skinCluster1GroupId.msg" "skinCluster1Set.gn" -na;
connectAttr "ponytail_MSHShape.iog.og[2]" "skinCluster1Set.dsm" -na;
connectAttr "skinCluster1.msg" "skinCluster1Set.ub[0]";
connectAttr "tweak3.og[0]" "skinCluster1GroupParts.ig";
connectAttr "skinCluster1GroupId.id" "skinCluster1GroupParts.gi";
connectAttr "groupId6.msg" "tweakSet3.gn" -na;
connectAttr "ponytail_MSHShape.iog.og[3]" "tweakSet3.dsm" -na;
connectAttr "tweak3.msg" "tweakSet3.ub[0]";
connectAttr "ponytail_MSHShapeOrig.w" "groupParts6.ig";
connectAttr "groupId6.id" "groupParts6.gi";
connectAttr "sim_ponytail01_JNT.msg" "bindPose1.m[0]";
connectAttr "sim_ponytail02_JNT.msg" "bindPose1.m[1]";
connectAttr "sim_ponytail03_JNT.msg" "bindPose1.m[2]";
connectAttr "sim_ponytail04_JNT.msg" "bindPose1.m[3]";
connectAttr "sim_ponytail05_JNT.msg" "bindPose1.m[4]";
connectAttr "sim_ponytail06_JNT.msg" "bindPose1.m[5]";
connectAttr "sim_ponytail07_JNT.msg" "bindPose1.m[6]";
connectAttr "bindPose1.w" "bindPose1.p[0]";
connectAttr "bindPose1.m[0]" "bindPose1.p[1]";
connectAttr "bindPose1.m[1]" "bindPose1.p[2]";
connectAttr "bindPose1.m[2]" "bindPose1.p[3]";
connectAttr "bindPose1.m[3]" "bindPose1.p[4]";
connectAttr "bindPose1.m[4]" "bindPose1.p[5]";
connectAttr "bindPose1.m[5]" "bindPose1.p[6]";
connectAttr "sim_ponytail01_JNT.bps" "bindPose1.wm[0]";
connectAttr "sim_ponytail02_JNT.bps" "bindPose1.wm[1]";
connectAttr "sim_ponytail03_JNT.bps" "bindPose1.wm[2]";
connectAttr "sim_ponytail04_JNT.bps" "bindPose1.wm[3]";
connectAttr "sim_ponytail05_JNT.bps" "bindPose1.wm[4]";
connectAttr "sim_ponytail06_JNT.bps" "bindPose1.wm[5]";
connectAttr "sim_ponytail07_JNT.bps" "bindPose1.wm[6]";
connectAttr "bindPose1.msg" "geomBind1.bp";
connectAttr "blinn1SG.pa" ":renderPartition.st" -na;
connectAttr "ponytail_SUB.msg" ":defaultShaderList1.s" -na;
connectAttr "defaultRenderLayer.msg" ":defaultRenderingList1.r" -na;
// End of ponytail_skeleton_step04.ma
