<CharacterDefinition>
 <Model File="objects/jigglebone_tutorial_maya/ponytail_skel.chr"/>
 <AttachmentList>
  <Attachment Type="CA_SKIN" AName="ponytail_msh" Binding="objects/jigglebone_tutorial_maya/ponytail_msh.skin" Flags="0"/>
  <Attachment Type="CA_BONE" AName="ponytail01" RelRotation="0.86602533,0,-0.49999997,0" RelPosition="0,0,0" BoneName="sim_ponytail01_JNT" PA_PendulumType="1" PA_Redirect="1" PA_Damping="3" PA_Stiffness="1" PA_SimulationAxis="10,0,0" Flags="0"/>
  <Attachment Type="CA_BONE" AName="ponytail02" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail02_JNT" PA_PendulumType="1" PA_Redirect="1" PA_Damping="6" PA_SimulationAxis="1,0,0" Flags="0"/>
  <Attachment Type="CA_BONE" AName="ponytail03" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail03_JNT" PA_PendulumType="1" PA_Redirect="1" PA_Damping="6" PA_Stiffness="15" PA_SimulationAxis="1,0,0" Flags="0"/>
  <Attachment Type="CA_BONE" AName="ponytail04" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail04_JNT" PA_PendulumType="1" PA_Redirect="1" PA_Damping="6" PA_Stiffness="15" PA_SimulationAxis="1,0,0" Flags="0"/>
  <Attachment Type="CA_BONE" AName="ponytail05" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail05_JNT" PA_PendulumType="1" PA_Redirect="1" PA_Damping="6" PA_Stiffness="15" PA_SimulationAxis="1,0,0" Flags="0"/>
  <Attachment Type="CA_BONE" AName="ponytail06" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail06_JNT" PA_PendulumType="1" PA_Redirect="1" PA_Damping="6" PA_Stiffness="15" PA_SimulationAxis="0.5,0,0" Flags="0"/>
  <Attachment Type="CA_BONE" AName="ponytail07" RelRotation="1,0,0,0" RelPosition="0,0,0" BoneName="sim_ponytail07_JNT" PA_PendulumType="1" PA_Redirect="1" PA_Damping="6" PA_Stiffness="15" PA_SimulationAxis="0.30000001,0,0" Flags="0"/>
 </AttachmentList>
</CharacterDefinition>
