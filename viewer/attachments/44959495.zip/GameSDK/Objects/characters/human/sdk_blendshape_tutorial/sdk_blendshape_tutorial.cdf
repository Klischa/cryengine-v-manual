<CharacterDefinition>
 <Model File="objects/characters/human/sdk_blendshape_tutorial/sdk_player_head_skel.chr"/>
 <AttachmentList>
  <Attachment Type="CA_SKIN" AName="sdk_player_head" Binding="objects/characters/human/sdk_blendshape_tutorial/sdk_player_head.skin" Material="objects/characters/human/sdk_blendshape_tutorial/head_a.mtl" Flags="8"/>
 </AttachmentList>
</CharacterDefinition>
