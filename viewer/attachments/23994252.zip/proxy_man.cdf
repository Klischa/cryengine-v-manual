<CharacterDefinition>
 <Model File="objects/characters/proxy_man_base.chr"/>
 <AttachmentList>
  <Attachment Type="CA_SKIN" AName="body" Binding="objects/characters/proxy_man.skin" Flags="0"/>
 </AttachmentList>
</CharacterDefinition>
