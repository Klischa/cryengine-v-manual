@echo off
SetLocal EnableDelayedExpansion

set "sourceFolder=%~dp0\..\..\fmod\assets\"

for /f %%x in (%~dp0\crytek_languages.txt) do (
	set "targetFolder=%~dp0\..\..\..\localization\%%x\audio\fmod\assets\"
	if exist !sourceFolder!*_%%x.bank if not exist !targetFolder! mkdir !targetFolder!
		for %%f in (!sourceFolder!*_%%x.bank) do (
			set "oldName=%%~nxf"
			set "newName=!oldName:_%%x.bank=.bank!"
			set "newFile=!targetFolder!!newName!"
			del /f /q !newFile!
			move %%f !newFile!
		)
		for %%f in (!sourceFolder!*_%%x.assets.bank) do (
			set "oldName=%%~nxf"
			set "newName=!oldName:_%%x.assets.bank=.assets.bank!"
			set "newFile=!targetFolder!!newName!"
			del /f /q !newFile!
			move %%f !newFile!
		)
		for %%f in (!sourceFolder!*_%%x.streams.bank) do (
			set "oldName=%%~nxf"
			set "newName=!oldName:_%%x.streams.bank=.streams.bank!"
			set "newFile=!targetFolder!!newName!"
			del /f /q !newFile!
			move %%f !newFile!
		)
)