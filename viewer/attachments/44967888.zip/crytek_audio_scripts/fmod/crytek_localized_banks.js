studio.project.buildEnded.connect(function(success) {
	studio.system.startAsync(__dirname + "/crytek_move_banks_pc.bat", {});
	studio.system.startAsync(__dirname + "/crytek_move_banks_ps4.bat", {});
	studio.system.startAsync(__dirname + "/crytek_move_banks_xboxone.bat", {});
});