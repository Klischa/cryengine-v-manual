rem English(US)
if exist "%~dp0\..\..\wwise\assets\English(US)\" if not exist "%~dp0\..\..\..\localization\english\audio\wwise\assets\" mkdir "%~dp0\..\..\..\localization\english\audio\wwise\assets\"
if exist "%~dp0\..\..\wwise\assets\English(US)\*.bnk" move "%~dp0\..\..\wwise\assets\English(US)\*" "%~dp0\..\..\..\localization\english\audio\wwise\assets\"
if exist "%~dp0\..\..\wwise\assets\English(US)\" rd /s /q "%~dp0\..\..\wwise\assets\English(US)\"

rem German
if exist "%~dp0\..\..\wwise\assets\German\" if not exist "%~dp0\..\..\..\localization\german\audio\wwise\assets\" mkdir "%~dp0\..\..\..\localization\german\audio\wwise\assets\"
if exist "%~dp0\..\..\wwise\assets\German\*.bnk" move "%~dp0\..\..\wwise\assets\German\*" "%~dp0\..\..\..\localization\german\audio\wwise\assets\"
if exist "%~dp0\..\..\wwise\assets\German\" rd /s /q "%~dp0\..\..\wwise\assets\German\"