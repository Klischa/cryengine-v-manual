rem English(US)
if exist "%~dp0\..\..\..\!ps4\audio\wwise\assets\English(US)\" if not exist "%~dp0\..\..\..\!ps4\localization\english\audio\wwise\assets\" mkdir "%~dp0\..\..\..\!ps4\localization\english\audio\wwise\assets\"
if exist "%~dp0\..\..\..\!ps4\audio\wwise\assets\English(US)\*.bnk" move "%~dp0\..\..\..\!ps4\audio\wwise\assets\English(US)\*" "%~dp0\..\..\..\!ps4\localization\english\audio\wwise\assets\"
if exist "%~dp0\..\..\..\!ps4\audio\wwise\assets\English(US)\" rd /s /q "%~dp0\..\..\..\!ps4\audio\wwise\assets\English(US)\"

rem German
if exist "%~dp0\..\..\..\!ps4\audio\wwise\assets\German\" if not exist "%~dp0\..\..\..\!ps4\localization\german\audio\wwise\assets\" mkdir "%~dp0\..\..\..\!ps4\localization\german\audio\wwise\assets\"
if exist "%~dp0\..\..\..\!ps4\audio\wwise\assets\German\*.bnk" move "%~dp0\..\..\..\!ps4\audio\wwise\assets\German\*" "%~dp0\..\..\..\!ps4\localization\german\audio\wwise\assets\"
if exist "%~dp0\..\..\..\!ps4\audio\wwise\assets\German\" rd /s /q "%~dp0\..\..\..\!ps4\audio\wwise\assets\German\"