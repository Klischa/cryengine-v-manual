@echo off
SetLocal EnableDelayedExpansion

for /f %%x in (%~dp0\languages.txt) do (
set "sourceFolder=%~dp0\..\PC\%%x\"
set "targetFolder=%~dp0\..\..\..\localization\%%x\audio\adx2\assets\"
if exist !sourceFolder! if not exist !targetFolder! mkdir !targetFolder!
if exist "!sourceFolder!*.acb" move "!sourceFolder!*.acb" !targetFolder!
if exist "!sourceFolder!*.awb" move "!sourceFolder!*.awb" !targetFolder!
if exist "!sourceFolder!*.xml" move "!sourceFolder!*.xml" !targetFolder!
if exist !sourceFolder! rd /s /q !sourceFolder!
)

set "sourceFolder=%~dp0\..\PC\"
set "targetFolder=%~dp0\..\..\adx2\assets\"
if exist !sourceFolder! if not exist !targetFolder! mkdir !targetFolder!
if exist "!sourceFolder!*.acf" move "!sourceFolder!*.acf" !targetFolder!
if exist "!sourceFolder!*.acb" move "!sourceFolder!*.acb" !targetFolder!
if exist "!sourceFolder!*.awb" move "!sourceFolder!*.awb" !targetFolder!
if exist "!sourceFolder!*.xml" move "!sourceFolder!*.xml" !targetFolder!
if exist !sourceFolder! rd /s /q !sourceFolder!