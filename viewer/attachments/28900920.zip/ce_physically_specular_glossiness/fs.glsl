//////////////////////////////// Fragment shader
#version 120
#extension GL_ARB_shader_texture_lod : require

#include "../common/common.glsl"
#include "../common/parallax.glsl"

varying vec2 iFS_UV;
varying vec3 iFS_Tangent;
varying vec3 iFS_Binormal;
varying vec3 iFS_PointWS;

uniform vec3 Lamp0Pos = vec3(0.0,0.0,70.0);
uniform vec3 Lamp0Color = vec3(1.0,1.0,1.0);
uniform float Lamp0Intensity = 1.0;
uniform vec3 Lamp1Pos = vec3(70.0,0.0,0.0);
uniform vec3 Lamp1Color = vec3(0.198,0.198,0.198);
uniform float Lamp1Intensity = 1.0;

uniform float AmbiIntensity = 1.0;
uniform float EmissiveIntensity = 1.0;


uniform vec3 TransmittanceColor= vec3(1,1,1);
uniform float BackDiffuseMultiplier = 0.85;
uniform float tiling = 1.0;
uniform float envRotation = 0.0;
uniform float Depth = 0.0;
uniform float SelfShadowStrenght = 0.0;
uniform float HeightBias = 1.0;
uniform bool flipY = true;
uniform bool perFragBinormal = true;
uniform bool sRGBBaseColor = true;
uniform bool sRGBspec = true;
uniform bool enablePOM = false;
uniform float SunMultiplier = 1.0;

uniform sampler2D heightMap;
uniform sampler2D normalMap;
uniform sampler2D baseColorMap;
uniform sampler2D specularMap;
uniform sampler2D glossinessMap;
uniform sampler2D aoMap;
uniform sampler2D emissiveMap;
uniform sampler2D environmentMap;
uniform sampler2D transmissiveMap;

uniform mat4 viewInverseMatrix;

// Number of miplevels in the envmap
uniform float maxLod = 10.0;

// Sample Pos table
uniform sampler2D vanDerCorputMap;
// Sample table Texture Width
// See cTextureWidth contant in samplespostableloader.cpp
const int vanDerCorputMapWidth = 512;
const int vanDerCorputMapHeight = 4;
// Actual number of samples in the table
uniform int nbSamples = 16;


// Irradiance spherical harmonics polynomial coefficients
// This is a color 2nd degree polynomial in (x,y,z), so it needs 10 coefficients
// for each color channel
uniform vec3 shCoefs[10];

// This must be included after the declaration of the uniform arrays since they
// can't be passed as functions parameters for performance reasons (on macs)
#include "../common/pbr_ibl.glsl"

varying vec3 iFS_Normal;
float fit_roughness(float r)
{
// Fit roughness values to a more usable curve
	return r;
}




vec3 CEIBLSpecularContributionQMC(
	sampler2D environmentMap, 
	float envRotation, 
	float maxLod,
	sampler2D vanDerCorputMap, 
	int vanDerCorputMapWidth,
	int vanDerCorputMapHeight,
	int nbSamples,
	vec3 fixedNormalWS, 
	vec3 Tp, 
	vec3 Bp,
	vec3 pointToCameraDirWS,
	vec3 specColor, 
	float roughness)
{
	vec3 sum = vec3(0.0,0.0,0.0);

	float ndv = max( 1e-8, abs(dot( pointToCameraDirWS, fixedNormalWS )) );

	for(int i=0; i<nbSamples; ++i)
	{
		vec2 Xi = hammersley2D(vanDerCorputMap, i, vanDerCorputMapWidth, vanDerCorputMapHeight, nbSamples);
		vec3 Hn = importanceSampleGGX(Xi,Tp,Bp,fixedNormalWS,roughness);
		vec3 Ln = -reflect(pointToCameraDirWS,Hn);

		float ndl = dot(fixedNormalWS, Ln);

		// Horizon fading trick from http://marmosetco.tumblr.com/post/81245981087
		const float horizonFade = 1.3;
		float horiz = clamp( 1.0 + horizonFade * ndl, 0.0, 1.0 );
		horiz *= horiz;
		ndl = max( 1e-8, abs(ndl) );

		float vdh = max( 1e-8, abs(dot(pointToCameraDirWS, Hn)) );
		float ndh = max( 1e-8, abs(dot(fixedNormalWS, Hn)) );
		float lodS = roughness < 0.01 ? 0.0 :
			computeLOD(
				Ln,
				probabilityGGX(ndh, vdh, roughness),
				nbSamples,
				maxLod);
		sum +=
			samplePanoramicLOD(environmentMap,rotate(Ln,envRotation),lodS) *
			microfacets_contrib(
				vdh, ndh, ndl, ndv,
				specColor,
				roughness) * horiz; 
	}

	return sum / nbSamples;
}

float GetLuminance( vec3 color )
{
	return dot( color, vec3( 0.2126, 0.7152, 0.0722 ) );
}

float SmoothnessToRoughness(float smoothness)
{
	return (1.0 - smoothness) * (1.0 - smoothness);
}

float DiffuseBRDF(vec3 N, vec3 V, vec3 L, float Gloss, float NdotL)
{
	// TODO: Merge with Specular BRDF to save a few instructions
	
	float m = SmoothnessToRoughness(Gloss);
	m *= m * m;  // Map GGX to Oren-Nayar roughness (purely empirical remapping)
	
	// Approximation of the full quality Oren-Nayar model
	float s = dot(L, V) - dot(N, L) * dot(N, V);
	float t = s <= 0 ? 1 : max(max(dot(N, L), dot(N, V)), 1e-6);
	float A = 1.0 / (1.0 + (0.5 - 2.0 / (3.0 * 3.1415)) * m);
	float B = m * A;
	
	return NdotL * max(A + B * (s / t), 0);
}

vec3 PhysicalBRDF(vec3 N, vec3 V, vec3 L, float m, vec3 SpecCol, float NormalizationFactor)
{
	float m2 = m * m;

	// Half vector
	vec3 H = normalize( V + L );

	// GGX NDF
	float NdotH = clamp( dot( N, H ),0.0,1.0 );
	float spec = (NdotH * NdotH) * (m2 - 1) + 1;
	spec = m2 / (spec * spec) * NormalizationFactor;
	
	// Schlick-Smith Visibility Term
	float k = (0.8 + m * 0.5) * (0.8 + m * 0.5) / 2;
	float Gv = clamp( dot( N, V ),0.0,1.0 ) * (1 - k) + k;
	float Gl = clamp( dot( N, L ),0.0,1.0 ) * (1 - k) + k;
	spec /= max( Gv * Gl, 1e-6 );
		
	// Schlick approximation for Fresnel
	vec3 fresnel = mix( SpecCol, vec3(1.0,1.0,1.0), pow( 1 - dot(L, H), 5 ) );

	return (fresnel * spec) / 4.0;
}

vec3 PhysicalBRDF(vec3 N, vec3 V, vec3 L, float Gloss, vec3 SpecCol)
{
	float m = max(SmoothnessToRoughness( Gloss ), 0.001);  // Prevent highlights from getting too tiny without area lights
	return PhysicalBRDF(N, V, L, m, SpecCol, 1.0);
}

vec3 ParallaxOcclusionMap(vec2 baseTC,  float lod, vec3 viewDirNrm,  int numSteps,  float displacement,  float bias)
{
	float step =  1.0 / numSteps;
	float bumpScale = displacement;

	vec2 delta = vec2(viewDirNrm.x, viewDirNrm.y) * bumpScale / (-viewDirNrm.z * numSteps); // / max(-viewDirNrm.z * numSteps, 0.1)

	baseTC -= (1.0 - bias) * numSteps * delta;

	float NB0 = texture2D(heightMap, baseTC).r;


	float height = 1 - step;
	vec4 offset = vec4(baseTC + delta, 0, lod);

	float NB1 = texture2D(heightMap, offset.xy).r;


	for (int i=0; i<numSteps; i++)
	{
	//	[flatten]
		if (NB1 >= height)
			break;

		NB0 = NB1;

		height -= step;
		offset.xy += delta;

		NB1 = texture2DLod(heightMap, offset.xy, offset.w).r;

	}

	vec4 offsetBest = offset;
	float error = 1.0;

	float t1 = height;
	float t0 = t1 + step;

	float delta1 = t1 - NB1;
	float delta0 = t0 - NB0;

	vec4 intersect = vec4(delta * numSteps, delta * numSteps + baseTC);

	float t = 0;

	for (int i=0; i<10; i++)
	{
	//	[flatten]
		if (abs(error) <= 0.01)
			break;

		float denom = delta1 - delta0;
		t = (t0 * delta1 - t1 * delta0) / denom;
		offsetBest.xy = -t * intersect.xy + intersect.zw;

		float NB = texture2DLod(heightMap, offsetBest.xy, offsetBest.w).r;


		error = t - NB;
		if (error < 0)
		{
			delta1 = error;
			t1 = t;
		}
		else
		{
			delta0 = error;
			t0 = t;
		}
	}
	return vec3(offsetBest.xy, t); 
}

float ComputeTextureLOD(vec2 uv,vec2 texDim)
{
	uv *= texDim;
	
	vec2 ddx_ = dFdx(uv);
	vec2 ddy_ = dFdy(uv);
	vec2 mag = abs(ddx_) + abs(ddy_);
	
	float lod = log2(max(mag.x, mag.y));
	return lod;
}

vec3 ThinTranslucency(vec3 N, vec3 L, vec3 transmittanceColor)
{
	float transmittance = clamp(dot(-N, L) + 0.2, 0.0, 1.0);
	
	float fresnel = (1 - transmittance) * (1 - transmittance);
	fresnel *= fresnel;
	
	return transmittance * (1 - fresnel) * transmittanceColor;
}

void main()
{
	vec3 normalWS = iFS_Normal;
	vec3 tangentWS = iFS_Tangent;
	vec3 binormalWS = perFragBinormal ?
		fixBinormal(normalWS,tangentWS,iFS_Binormal) : iFS_Binormal;

	vec3 cameraPosWS = viewInverseMatrix[3].xyz;
	vec3 pointToLight0DirWS = normalize(Lamp0Pos - iFS_PointWS);
	vec3 pointToLight1DirWS = normalize(Lamp1Pos - iFS_PointWS);
	vec3 pointToCameraDirWS = normalize(cameraPosWS - iFS_PointWS);

	vec2 uv = iFS_UV * tiling;
	
	float mdDisplacement = 1.0;
	if(enablePOM)
	{
		float lod = ComputeTextureLOD(uv, vec2(4096,4096));

		vec3 s = vec3(dot(pointToCameraDirWS,tangentWS) ,dot(pointToCameraDirWS,binormalWS), dot(pointToCameraDirWS,normalWS));
		mdDisplacement = Depth*0.05;
		float mdHeightBias = HeightBias;
		vec3 offsetBest = ParallaxOcclusionMap(uv, lod, s, 15, mdDisplacement, mdHeightBias);
		uv.xy = offsetBest.xy;
	}
	

	
	
	// ------------------------------------------
	// Add Normal from normalMap
	vec3 fixedNormalOS = normalWS;  // HACK for empty normal textures
	vec3 normalTS = texture2D(normalMap,uv).xyz;
	if(length(normalTS)>0.0001)
	{
		normalTS = fixNormalSample(normalTS,flipY);
		fixedNormalOS = normalize(
			normalTS.x*tangentWS +
			normalTS.y*binormalWS +
			normalTS.z*normalWS );
	}

	vec3 fixedNormalWS = fixedNormalOS;

	// ------------------------------------------
	// Compute material model (diffuse, specular & glossiness)
	//const vec3 dielectricColor = vec3(0.04, 0.04, 0.04);
	const float minRoughness=1e-4;
	// Convert the base color from sRGB to linear (we should have done this when
	// loading the texture but there is no way to specify which colorspace is
	// uѕed for a given texture in Designer yet)

	vec3 diffColor = srgb_to_linear( texture2D(baseColorMap,uv).rgb ) ;	
		
	vec3 specColor = sRGBspec ?	srgb_to_linear( texture2D(specularMap,uv).rgb ) :texture2D(specularMap,uv).rgb;
	float fGloss = texture2D(glossinessMap,uv).r;
	float roughness = max(minRoughness, fit_roughness(1.0 - fGloss));
	
	vec3 Tp,Bp;
	computeSamplingFrame(iFS_Tangent, iFS_Binormal, fixedNormalWS, Tp, Bp);
	vec3 specCubeMap = CEIBLSpecularContributionQMC(
		environmentMap, 
		envRotation, 
		maxLod-2,
		vanDerCorputMap,
		vanDerCorputMapWidth,
		vanDerCorputMapHeight,
		nbSamples,
		fixedNormalWS, 
		Tp, 
		Bp,
		pointToCameraDirWS,
		specColor, 
		roughness);
	vec3 diffCubeMap = irradianceFromSH(rotate(fixedNormalWS,envRotation));
	
	vec3 albedo = diffColor;
	albedo *= clamp( 1 - GetLuminance( specColor ), 0.0, 1.0 );
	
	vec3 cDiffuse = vec3(0,0,0);
	vec3 cSpecular = vec3(0,0,0);
	
	vec3 SunColor = linear_to_srgb(Lamp0Color.xyz * Lamp0Intensity * SunMultiplier);
	vec3 nm = 0.5*(normalize(fixedNormalWS)+vec3(1,1,1));
	
	vec3 sunDir = normalize(Lamp0Pos.xyz);
	float NdotL = clamp( dot( sunDir, fixedNormalWS ), 0.0, 1.0 );
	
	vec3 Transmittance = vec3(1,1,1);
	
	float fTranslucency = BackDiffuseMultiplier;	
	fTranslucency *= texture2D(transmissiveMap, uv).r;
	
	
	
	Transmittance = clamp(fTranslucency, 0.0, 1.0 ) * TransmittanceColor.rgb;
	
	
	vec3 sunSpec = PhysicalBRDF( normalize(fixedNormalWS), normalize(pointToCameraDirWS),  sunDir, fGloss, specColor );// * SunColor.w;
	float diffuseTerm = DiffuseBRDF(normalize(fixedNormalWS),  normalize(pointToCameraDirWS),  sunDir, fGloss, NdotL);
	vec3 transmittance = ThinTranslucency(fixedNormalWS, sunDir, Transmittance);
	float fSelfShadowing = 1.0;
	if(enablePOM)
	{
		vec3 light = vec3(dot(sunDir,tangentWS) ,dot(sunDir,binormalWS), dot(sunDir,normalWS));

		vec2 lightDelta = vec2(light.x, light.y) * mdDisplacement;


		float h0 = texture2D(heightMap, uv).r;
		float h = h0;

		h = max(0, texture2D(heightMap, uv + 1.000 * lightDelta).r);
		h = max(h, texture2D(heightMap, uv + 0.875 * lightDelta).r);
		h = max(h, texture2D(heightMap, uv + 0.750 * lightDelta).r);
		h = max(h, texture2D(heightMap, uv + 0.625 * lightDelta).r);
		h = max(h, texture2D(heightMap, uv + 0.500 * lightDelta).r);
		h = max(h, texture2D(heightMap, uv + 0.375 * lightDelta).r);
		h = max(h, texture2D(heightMap, uv + 0.250 * lightDelta).r);
		h = max(h, texture2D(heightMap, uv + 0.125 * lightDelta).r);


		fSelfShadowing = 1- clamp((h - h0) * SelfShadowStrenght, 0.0, 1.0);	
	}


	cDiffuse = (diffCubeMap * AmbiIntensity) + ( SunColor.xyz*fSelfShadowing ) * (diffuseTerm + transmittance);	
	cSpecular = specCubeMap * AmbiIntensity;
	cSpecular += sunSpec * NdotL * SunColor.xyz*fSelfShadowing;
	
	vec3 res =  albedo * cDiffuse + cSpecular;
	//gl_FragColor = vec4(linear_to_srgb(vec3(fSelfShadowing,fSelfShadowing,fSelfShadowing)), 1.0);
	
	gl_FragColor = vec4(linear_to_srgb(res), 1.0);
	return;
	

}

