<CharacterDefinition>
 <Model File="Objects/tutorial/animated_blendshape_tutorial/max/sdk_player_head_max_skel.chr"/>
 <AttachmentList>
  <Attachment Type="CA_SKIN" AName="sdk_player_head_max" Binding="Objects/tutorial/animated_blendshape_tutorial/max/sdk_player_head_max.skin" Material="Objects/characters/human/sdk_player/head_a.mtl" Flags="8"/>
 </AttachmentList>
</CharacterDefinition>
